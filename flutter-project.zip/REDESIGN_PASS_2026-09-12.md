# XEON UI/UX REDESIGN PASS — 2026-09-12

This pass is a visual redesign pass only. Existing feature structure, API calls,
HTTP/WebSocket logic, authentication/session flow, constructors and callbacks
were not intentionally rewritten.

## Visual direction
- 3D comic paper-craft language
- premium, clean, soft/muted palette
- muted medium orange as primary accent
- cream/off-white paper surfaces
- controlled depth and cartoon outlines
- reduced neon/cyberpunk saturation
- reference images are treated as design-language inspiration, not layout templates

## Safety fixes
- Removed an invalid `SystemUiOverlayStyle` configuration block from `main.dart`
  that contained ThemeData-only fields and could prevent compilation.
- Made dashboard navigation switch cases explicit with returns to avoid accidental
  fall-through diagnostics.
- Kept existing navigation/page constructors intact.

## Important
Flutter/Dart SDK is not installed in the current execution environment, so
`flutter analyze` and `flutter build apk --release` could not be executed here.
Run those commands in the project's Flutter environment before shipping.
