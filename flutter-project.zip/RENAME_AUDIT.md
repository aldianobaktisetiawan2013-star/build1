# Rename Audit

- Android display name: Xeon
- iOS display name: Xeon
- Public Telegram person: @krizoficialll / https://t.me/krizoficialll
- Public Telegram channel: @Panzxteam / https://t.me/Panzxteam
- Flutter package identifier `Xeon` intentionally retained for compatibility.
