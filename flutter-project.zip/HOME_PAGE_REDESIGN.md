# Home Page Redesign Pass

- Rebuilt `lib/home_page.dart` visual widget tree.
- Preserved existing controllers, network requests, validation, callbacks, state, video banner and navigation behavior.
- Removed the dark aurora/neon layout from the HomePage render path.
- Added reusable matte comic primitives: ComicPanel, ComicSection, ComicIcon, ComicBadge, ComicChoice and ComicModeCard.
- Replaced glow-heavy cards with hard-depth, rounded matte panels.
- Improved overflow handling with Expanded, Wrap and ellipsis.
- Kept the app-wide ComicAppShell for the remaining routes so the global matte comic behavior remains consistent.

This pass intentionally changes presentation without deleting existing actions or service calls.
