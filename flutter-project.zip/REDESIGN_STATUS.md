# ACTIVE TOTAL UI REDESIGN
This copy is the active worktree. `UI_REDESIGN_WORKLIST.json` is the source-of-truth inventory.
No file may be marked complete merely because the global theme changes; UI files require an explicit redesign pass and final audit.
