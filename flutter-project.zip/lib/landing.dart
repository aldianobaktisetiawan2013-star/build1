// XEON — Opening / Welcome visual pass.
// Existing route and navigation are preserved. This file changes presentation only.
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';
import 'design_system/comic_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late final PageController _pageController;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: .91);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ComicScaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 14),
            _TopMark(),
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                itemCount: 3,
                physics: const BouncingScrollPhysics(),
                onPageChanged: (index) {
                  setState(() => _page = index);
                },
                itemBuilder: (context, index) {
                  return AnimatedBuilder(
                    animation: _pageController,
                    builder: (context, child) {
                      final current = _pageController.hasClients
                          ? (_pageController.page ?? _page.toDouble())
                          : _page.toDouble();

                      final distance =
                          (current - index).abs().clamp(0.0, 1.0);

                      final scale = 1 - (distance * .045);
                      final x = (current - index).clamp(-1.0, 1.0);

                      return Transform(
                        alignment: Alignment.center,
                        transform: Matrix4.identity()
                          ..setEntry(3, 2, .0018)
                          ..rotateY(x * -.055)
                          ..scale(scale),
                        child: Opacity(
                          opacity: 1 - distance * .18,
                          child: child,
                        ),
                      );
                    },
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(6, 22, 6, 18),
                      child: _pageContent(index),
                    ),
                  );
                },
              ),
            ),
            _PageIndicator(
              active: _page,
              count: 3,
            ),
            const SizedBox(height: 12),
            _BottomAction(
              onLogin: () => Navigator.pushNamed(context, '/login'),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _pageContent(int index) {
    switch (index) {
      case 1:
        return const _PersonPage(
          image: 'assets/images/developer_kriz.jpg',
          role: 'DEVELOPER',
          handle: '@krizoficiall',
          title: 'Developer XEON',
          description: 'Pengembang di balik project XEON.',
        );

      case 2:
        return const _PersonPage(
          image: 'assets/images/support_panz.jpg',
          role: 'SUPPORT',
          handle: '@panzkecebaday',
          title: 'Support XEON',
          description: 'Support dan partner project XEON.',
        );

      default:
        return const _GreetingPage();
    }
  }
}

class _TopMark extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 9,
                height: 9,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.sageGreen,
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                'XEON',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const Text(
            'WELCOME',
            style: TextStyle(
              color: AppColors.textSub,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }
}

class _GreetingPage extends StatelessWidget {
  const _GreetingPage();

  @override
  Widget build(BuildContext context) {
    return _PaperPage(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _LogoPaper(),
          const SizedBox(height: 28),
          const Text(
            'HALO 👋',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              color: AppColors.dustyBlue,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Selamat datang di XEON',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 31,
              height: 1.05,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Geser halaman kertas untuk mengenal orang di balik project ini.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              height: 1.55,
              color: AppColors.textSub,
            ),
          ),
          const SizedBox(height: 28),
          const _SwipeHint(),
        ],
      ),
    );
  }
}

class _PersonPage extends StatelessWidget {
  final String image;
  final String role;
  final String handle;
  final String title;
  final String description;

  const _PersonPage({
    required this.image,
    required this.role,
    required this.handle,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return _PaperPage(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: _Label(text: role),
          ),
          const SizedBox(height: 22),
          Transform.rotate(
            angle: -0.018,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFF4EBDD),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: AppColors.borderActive,
                  width: 1.8,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x331A1816),
                    offset: Offset(0, 7),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: AspectRatio(
                  aspectRatio: 1,
                  child: Image.asset(
                    image,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            handle,
            style: const TextStyle(
              color: AppColors.dustyBlue,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            description,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AppColors.textSub,
              fontSize: 13,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 18),
          const _SwipeHint(),
        ],
      ),
    );
  }
}

class _PaperPage extends StatelessWidget {
  final Widget child;

  const _PaperPage({
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: AppColors.borderActive,
          width: 2,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x33251F1A),
            offset: Offset(0, 9),
            blurRadius: 0,
          ),
          BoxShadow(
            color: Color(0x141A1816),
            offset: Offset(0, 2),
            blurRadius: 12,
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            top: 18,
            right: 20,
            child: _Doodle(),
          ),
          Positioned(
            bottom: 18,
            left: 20,
            child: _Tape(),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
            child: child,
          ),
        ],
      ),
    );
  }
}

class _LogoPaper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 112,
      height: 112,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.dustyBlue,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: AppColors.borderActive,
          width: 2,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x33251F1A),
            offset: Offset(0, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(20),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Image.asset(
            'assets/images/logo.png',
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;

  const _Label({
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 11,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: AppColors.softMustard.withOpacity(.28),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.borderActive,
          width: 1.2,
        ),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
        ),
      ),
    );
  }
}

class _SwipeHint extends StatelessWidget {
  const _SwipeHint();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: const [
        Icon(
          Icons.swipe_rounded,
          size: 17,
          color: AppColors.textSub,
        ),
        SizedBox(width: 7),
        Text(
          'GESER HALAMAN',
          style: TextStyle(
            color: AppColors.textSub,
            fontSize: 10,
            fontWeight: FontWeight.w800,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }
}

class _Doodle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: .18,
      child: const Icon(
        Icons.auto_awesome_rounded,
        size: 20,
        color: AppColors.mutedCoral,
      ),
    );
  }
}

class _Tape extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: -.06,
      child: Container(
        width: 48,
        height: 13,
        decoration: BoxDecoration(
          color: AppColors.softMustard.withOpacity(.45),
          borderRadius: BorderRadius.circular(3),
        ),
      ),
    );
  }
}

class _PageIndicator extends StatelessWidget {
  final int active;
  final int count;

  const _PageIndicator({
    required this.active,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        count,
        (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: i == active ? 22 : 7,
          height: 7,
          decoration: BoxDecoration(
            color: i == active
                ? AppColors.dustyBlue
                : AppColors.border,
            borderRadius: BorderRadius.circular(10),
          ),
        ),
      ),
    );
  }
}

class _BottomAction extends StatelessWidget {
  final VoidCallback onLogin;

  const _BottomAction({
    required this.onLogin,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 22),
      child: Row(
        children: [
          Expanded(
            child: _ActionButton(
              label: 'MASUK SEKARANG',
              icon: Icons.login_rounded,
              color: AppColors.dustyBlue,
              onTap: onLogin,
            ),
          ),
          const SizedBox(width: 10),
          _SocialButton(
            icon: FontAwesomeIcons.telegram,
            onTap: () async {
              final uri = Uri.parse(
                'https://t.me/krizoficialll',
              );

              if (await canLaunchUrl(uri)) {
                await launchUrl(
                  uri,
                  mode: LaunchMode.externalApplication,
                );
              }
            },
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppColors.borderActive,
              width: 1.6,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x33251F1A),
                offset: Offset(0, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: Colors.white,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: .4,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SocialButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _SocialButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          width: 54,
          height: 50,
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: AppColors.borderActive,
              width: 1.6,
            ),
          ),
          child: Icon(
            icon,
            size: 20,
            color: AppColors.dustyBlue,
          ),
        ),
      ),
    );
  }
}