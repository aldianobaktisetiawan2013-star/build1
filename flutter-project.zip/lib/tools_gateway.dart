import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'all_quran.dart';
import 'pantun.dart';
import 'kata_kata.dart';
import 'puisi.dart';
import 'main.dart';
import 'design_system/comic_page.dart';

/// Visual-only presentation data. Tool routes and callbacks remain unchanged.
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final String count;
  const _ToolCategory({required this.id, required this.title, required this.subtitle, required this.icon, required this.accent, required this.count});
}

const _categories = <_ToolCategory>[
  _ToolCategory(id: 'ddos', title: 'DDoS Tools', subtitle: 'Attack & Server', icon: Icons.bolt_rounded, accent: AppColors.danger, count: '2'),
  _ToolCategory(id: 'network', title: 'Network', subtitle: 'WiFi & Spam', icon: Icons.wifi_tethering_rounded, accent: AppColors.warning, count: '3'),
  _ToolCategory(id: 'osint', title: 'OSINT', subtitle: 'Investigation', icon: Icons.travel_explore_rounded, accent: AppColors.violetBright, count: '4'),
  _ToolCategory(id: 'downloader', title: 'Downloader', subtitle: 'Social Media', icon: Icons.cloud_download_rounded, accent: Color(0xFFB56C72), count: '2'),
  _ToolCategory(id: 'utilities', title: 'Utilities', subtitle: 'Extra Tools', icon: Icons.construction_rounded, accent: AppColors.cyanDim, count: '3'),
  _ToolCategory(id: 'quran', title: 'Al-Quran', subtitle: 'Surat & Terjemah', icon: Icons.menu_book_rounded, accent: Color(0xFFD4AF37), count: '114'),
  _ToolCategory(id: 'pantun', title: 'Pantun', subtitle: 'Cinta & Lucu', icon: Icons.auto_stories_rounded, accent: Color(0xFFB56C72), count: '30'),
  _ToolCategory(id: 'katakata', title: 'Kata-Kata', subtitle: 'Bijak & Inspiratif', icon: Icons.format_quote_rounded, accent: AppColors.violetBright, count: '53'),
  _ToolCategory(id: 'puisi', title: 'Puisi', subtitle: 'Cinta & Motivasi', icon: Icons.menu_book_rounded, accent: Color(0xFFB56C72), count: '30'),
  _ToolCategory(id: 'quick', title: 'Quick Access', subtitle: 'Favorites', icon: Icons.rocket_launch_rounded, accent: AppColors.success, count: '—'),
];

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;
  const ToolsPage({super.key, required this.sessionKey, required this.userRole, required this.listDoos});
  @override State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  /// Preserves the existing animated navigation used by the Tools page.
  /// This helper is local to this page so tool routes/callbacks stay unchanged.
  PageRoute<T> _slideRoute<T>(Widget page) => PageRouteBuilder<T>(
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final offsetAnimation = Tween<Offset>(
            begin: const Offset(0.08, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          ));
          return FadeTransition(
            opacity: animation,
            child: SlideTransition(position: offsetAnimation, child: child),
          );
        },
      );
  late final PageController _controller;
  int _active = 0;

  @override void initState() { super.initState(); _controller = PageController(viewportFraction: .84); }
  @override void dispose() { _controller.dispose(); super.dispose(); }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _comingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
      content: Text('Coming Soon!'), behavior: SnackBarBehavior.floating,
    ));
  }

  void _onCategoryTap(String id) {
    switch (id) {
      case 'ddos': _showSheet(_ddosItems()); break;
      case 'network': _showSheet(_networkItems()); break;
      case 'osint': _showSheet(_osintItems()); break;
      case 'downloader': _showSheet(_downloaderItems()); break;
      case 'utilities': _showSheet(_utilityItems()); break;
      case 'quran': _push(const AllQuranPage()); break;
      case 'pantun': _push(const PantunPage()); break;
      case 'katakata': _push(const KataKataPage()); break;
      case 'puisi': _push(const PuisiPage()); break;
      case 'quick': _comingSoon(); break;
    }
  }

  List<_ToolItem> _ddosItems() => [
    _ToolItem(icon: Icons.bolt_rounded, label: 'Attack Panel', accent: AppColors.danger, onTap: () => _push(AttackPanel(sessionKey: widget.sessionKey, listDoos: widget.listDoos))),
    _ToolItem(icon: Icons.dns_rounded, label: 'Manage Server', accent: AppColors.warning, onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey))),
  ];
  List<_ToolItem> _networkItems() => [
    _ToolItem(icon: Icons.newspaper_outlined, label: 'Spam NGL', accent: AppColors.violetBright, onTap: () => _push(NglPage())),
    _ToolItem(icon: Icons.wifi_off_rounded, label: 'WiFi Killer (Internal)', accent: AppColors.warning, onTap: () => _push(WifiKillerPage())),
    if (widget.userRole == 'vip' || widget.userRole == 'owner')
      _ToolItem(icon: Icons.router_rounded, label: 'WiFi Killer (External)', accent: AppColors.danger, onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey))),
  ];
  List<_ToolItem> _osintItems() => [
    _ToolItem(icon: Icons.badge_outlined, label: 'NIK Detail', accent: AppColors.violetBright, onTap: () => _push(const DomainOsintPage())),
    _ToolItem(icon: Icons.person_search_rounded, label: 'Phone Lookup', accent: AppColors.cyanDim, onTap: _comingSoon, comingSoon: true),
    _ToolItem(icon: Icons.alternate_email_rounded, label: 'Email OSINT', accent: Color(0xFFB56C72), onTap: _comingSoon, comingSoon: true),
  ];
  List<_ToolItem> _downloaderItems() => [
    _ToolItem(icon: Icons.video_library_rounded, label: 'TikTok Downloader', accent: Color(0xFFB56C72), onTap: () => _push(const TiktokDownloaderPage())),
    _ToolItem(icon: Icons.camera_alt_rounded, label: 'Instagram Downloader', accent: AppColors.violetBright, onTap: () => _push(const InstagramDownloaderPage())),
  ];
  List<_ToolItem> _utilityItems() => [
    _ToolItem(icon: Icons.qr_code_2_rounded, label: 'QR Generator', accent: AppColors.cyanDim, onTap: () => _push(const QrGeneratorPage())),
    _ToolItem(icon: Icons.security_rounded, label: 'IP Scanner', accent: AppColors.warning, onTap: _comingSoon, comingSoon: true),
    _ToolItem(icon: Icons.network_check_rounded, label: 'Port Scanner', accent: AppColors.success, onTap: _comingSoon, comingSoon: true),
  ];

  @override Widget build(BuildContext context) {
    return ComicScaffold(
      backgroundColor: AppColors.bg,
      body: Stack(
        children: [
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _ToolsPaperPainter()))),
          SafeArea(
            child: Column(children: [
          const _ToolsBanner(),
          _ToolsHeader(total: _categories.length),
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 8, 20, 4),
            child: Align(alignment: Alignment.centerLeft, child: Text('Pilih menu dengan menggeser kartu', style: TextStyle(color: AppColors.textSub, fontSize: 12))),
          ),
          Expanded(
            child: PageView.builder(
              controller: _controller,
              itemCount: _categories.length,
              physics: const BouncingScrollPhysics(),
              onPageChanged: (value) => setState(() => _active = value),
              itemBuilder: (context, index) => AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  double page = _active.toDouble();
                  if (_controller.hasClients && _controller.position.hasContentDimensions) page = _controller.page ?? page;
                  final distance = (page - index).abs().clamp(0.0, 1.0);
                  return Transform.scale(scale: 1 - distance * .055, child: Opacity(opacity: 1 - distance * .22, child: child));
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(6, 12, 6, 30),
                  child: _ToolCarouselCard(category: _categories[index], onTap: () => _onCategoryTap(_categories[index].id)),
                ),
              ),
            ),
          ),
          _PageDots(active: _active, count: _categories.length),
          const SizedBox(height: 18),
        ]),
          ),
        ],
      ),
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (context) => _ToolSheet(items: items),
    );
  }
}

class _ToolsBanner extends StatefulWidget {
  const _ToolsBanner();
  @override
  State<_ToolsBanner> createState() => _ToolsBannerState();
}

class _ToolsBannerState extends State<_ToolsBanner> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 2),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _pressed = true),
        onTapCancel: () => setState(() => _pressed = false),
        onTapUp: (_) => setState(() => _pressed = false),
        child: AnimatedScale(
          scale: _pressed ? .985 : 1,
          duration: const Duration(milliseconds: 130),
          curve: Curves.easeOutBack,
          child: Container(
            padding: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(
              color: AppColors.borderActive,
              borderRadius: BorderRadius.circular(24),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: Container(
                height: 132,
                decoration: BoxDecoration(
                  color: AppColors.card,
                  border: Border.all(color: AppColors.borderActive, width: 2),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/images/banner_tools.jpg',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const ColoredBox(color: AppColors.surfaceAlt),
                    ),
                    DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: [
                            AppColors.borderActive.withOpacity(.72),
                            AppColors.borderActive.withOpacity(.16),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                    const Positioned(
                      left: 16,
                      bottom: 14,
                      child: _ToolsBannerLabel(),
                    ),
                    const Positioned(
                      right: 14,
                      top: 12,
                      child: _PaperTape(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ToolsBannerLabel extends StatelessWidget {
  const _ToolsBannerLabel();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(
      color: AppColors.card.withOpacity(.94),
      borderRadius: BorderRadius.circular(13),
      border: Border.all(color: AppColors.borderActive, width: 1.6),
      boxShadow: const [BoxShadow(color: Color(0x55181614), offset: Offset(0, 3), blurRadius: 0)],
    ),
    child: const Text(
      'XEON TOOLS',
      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, letterSpacing: 1.2),
    ),
  );
}

class _PaperTape extends StatelessWidget {
  const _PaperTape();
  @override
  Widget build(BuildContext context) => Transform.rotate(
    angle: .08,
    child: Container(
      width: 52,
      height: 18,
      decoration: BoxDecoration(
        color: const Color(0xFFE8D8B9).withOpacity(.86),
        border: Border.all(color: AppColors.borderActive.withOpacity(.24)),
      ),
    ),
  );
}

class _ToolsPaperPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFEEE3D2).withOpacity(.42);
    canvas.drawRect(Offset.zero & size, paint);
    final line = Paint()..color = const Color(0xFF7B6F63).withOpacity(.045)..strokeWidth = 1;
    for (double y = 24; y < size.height; y += 46) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), line);
    }
    final dot = Paint()..color = const Color(0xFFC9894A).withOpacity(.08);
    for (double x = 18; x < size.width; x += 72) {
      for (double y = 18; y < size.height; y += 72) {
        canvas.drawCircle(Offset(x, y), 1.7, dot);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ToolsHeader extends StatelessWidget {
  final int total;
  const _ToolsHeader({required this.total});
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
    child: _PaperSurface(
      padding: const EdgeInsets.all(16),
      child: Row(children: [
        Container(width: 46, height: 46, decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.borderActive, width: 1.4)), child: const Icon(Icons.handyman_rounded, color: AppColors.cyanDim)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('XEON TOOLS', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: .4)), SizedBox(height: 3), Text('Semua tools existing, tampilan baru', style: TextStyle(color: AppColors.textSub, fontSize: 11))])),
        _CountBadge(label: '$total MENU'),
      ]),
    ),
  );
}

class _ToolCarouselCard extends StatefulWidget {
  final _ToolCategory category; final VoidCallback onTap;
  const _ToolCarouselCard({required this.category, required this.onTap});
  @override State<_ToolCarouselCard> createState() => _ToolCarouselCardState();
}
class _ToolCarouselCardState extends State<_ToolCarouselCard> {
  bool down = false;
  @override Widget build(BuildContext context) {
    final c = widget.category;
    return GestureDetector(
      onTapDown: (_) => setState(() => down = true), onTapCancel: () => setState(() => down = false), onTapUp: (_) => setState(() => down = false), onTap: widget.onTap,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 120), scale: down ? .98 : 1,
        child: _PaperSurface(
          color: AppColors.card,
          padding: const EdgeInsets.all(22),
          child: LayoutBuilder(builder: (context, box) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              _ComicIcon(icon: c.icon, accent: c.accent),
              const Spacer(),
              _CountBadge(label: '${c.count} ITEM', accent: c.accent),
            ]),
            const Spacer(),
            Text(c.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 28, height: 1.02, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(c.subtitle, style: const TextStyle(color: AppColors.textSub, fontSize: 14)),
            const SizedBox(height: 22),
            Container(height: 1, color: AppColors.border.withOpacity(.55)),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: Text('Buka menu ${c.title}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
              Container(width: 44, height: 44, decoration: BoxDecoration(color: c.accent, shape: BoxShape.circle, border: Border.all(color: AppColors.borderActive, width: 1.6)), child: const Icon(Icons.arrow_forward_rounded, color: Colors.white)),
            ]),
          ])),
        ),
      ),
    );
  }
}

class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});
  @override Widget build(BuildContext context) => SafeArea(
    top: false,
    child: Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .72),
      decoration: const BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(28)), border: Border(top: BorderSide(color: AppColors.borderActive, width: 1.5), left: BorderSide(color: AppColors.borderActive, width: 1.5), right: BorderSide(color: AppColors.borderActive, width: 1.5))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(margin: const EdgeInsets.only(top: 10, bottom: 8), width: 42, height: 5, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(8))),
        const Padding(padding: EdgeInsets.fromLTRB(20, 4, 20, 12), child: Align(alignment: Alignment.centerLeft, child: Text('PILIH FITUR', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14))),),
        Flexible(child: ListView.separated(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, i) => _ToolRow(item: items[i], onTap: () { Navigator.pop(context); items[i].onTap(); }))),
      ]),
    ),
  );
}

class _ToolRow extends StatefulWidget {
  final _ToolItem item; final VoidCallback onTap;
  const _ToolRow({required this.item, required this.onTap});
  @override State<_ToolRow> createState() => _ToolRowState();
}
class _ToolRowState extends State<_ToolRow> {
  bool down = false;
  @override Widget build(BuildContext context) => GestureDetector(
    onTapDown: (_) => setState(() => down = true), onTapCancel: () => setState(() => down = false), onTapUp: (_) => setState(() => down = false), onTap: widget.onTap,
    child: AnimatedScale(duration: const Duration(milliseconds: 100), scale: down ? .985 : 1, child: _PaperSurface(
      padding: const EdgeInsets.all(13), child: Row(children: [
        _ComicIcon(icon: widget.item.icon, accent: widget.item.accent, small: true),
        const SizedBox(width: 12), Expanded(child: Text(widget.item.label, style: const TextStyle(fontWeight: FontWeight.w800))),
        if (widget.item.comingSoon) const _CountBadge(label: 'SOON'),
        const SizedBox(width: 8), const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
      ]),
    )),
  );
}

class _PaperSurface extends StatelessWidget {
  final Widget child; final EdgeInsetsGeometry padding; final Color color;
  const _PaperSurface({required this.child, this.padding = const EdgeInsets.all(16), this.color = AppColors.card});
  @override Widget build(BuildContext context) => Transform.translate(
    offset: const Offset(0, 3), child: Container(
      padding: const EdgeInsets.only(bottom: 5),
      decoration: BoxDecoration(color: AppColors.borderActive.withOpacity(.72), borderRadius: BorderRadius.circular(24)),
      child: Container(padding: padding, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.borderActive, width: 1.5)), child: child),
    ),
  );
}
class _ComicIcon extends StatelessWidget {
  final IconData icon; final Color accent; final bool small;
  const _ComicIcon({required this.icon, required this.accent, this.small = false});
  @override Widget build(BuildContext context) {
    final size = small ? 44.0 : 78.0;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: accent,
        borderRadius: BorderRadius.circular(small ? 15 : 24),
        border: Border.all(color: AppColors.borderActive, width: 1.8),
      ),
      child: Icon(icon, size: small ? 21 : 36, color: Colors.white),
    );
  }
}
class _CountBadge extends StatelessWidget {
  final String label; final Color? accent;
  const _CountBadge({required this.label, this.accent});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
    decoration: BoxDecoration(
      color: accent ?? AppColors.violet,
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: AppColors.borderActive, width: 1.4),
    ),
    child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: .4)),
  );
}
class _PageDots extends StatelessWidget {
  final int active, count; const _PageDots({required this.active, required this.count});
  @override Widget build(BuildContext context) => SizedBox(height: 10, child: ListView.separated(scrollDirection: Axis.horizontal, shrinkWrap: true, padding: EdgeInsets.zero, itemCount: count, separatorBuilder: (_, __) => const SizedBox(width: 5), itemBuilder: (_, i) => AnimatedContainer(duration: const Duration(milliseconds: 180), width: i == active ? 24 : 7, height: 7, decoration: BoxDecoration(color: i == active ? AppColors.cyanDim : AppColors.border, borderRadius: BorderRadius.circular(8)))));
}
class _ToolItem {
  final IconData icon; final String label; final Color accent; final VoidCallback onTap; final bool comingSoon;
  _ToolItem({required this.icon, required this.label, required this.accent, required this.onTap, this.comingSoon = false});
}
