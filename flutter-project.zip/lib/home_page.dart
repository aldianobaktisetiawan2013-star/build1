// COMIC_MATTE_UI_PASS: all screens inherit the shared 3D Comic Matte component system.
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';
import 'design_system/comic_page.dart';

const _baseUrl = 'http://kontolilegalzyro.rexypediaa.biz.id:3055';

bool _canGlobal(String r) {
  final l = r.toLowerCase();
  return l == 'high owner' || l == 'owner' || l == 'high admin' || l == 'vip';
}

class HomePage extends StatefulWidget {
  final String username, password, sessionKey, role, expiredDate;
  final List<Map<String, dynamic>> listBug;
  final String bugMode;
  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    this.bugMode = 'number',
  });
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl    = TextEditingController();
  final _bugScrollCtrl = ScrollController();
  String  _selectedBugId = '';
  String  _bugMode    = 'number';
  String  _senderType = 'private';
  bool    _isSending  = false;
  String? _responseMsg;
  List<String> _globalSenders = [];
  bool _loadingSenders = false;

  late AnimationController _auroraCtrl, _entranceCtrl, _btnCtrl, _resultCtrl, _pulseCtrl, _glowCtrl;
  late Animation<double> _fade, _btnGlow, _resultFade, _pulse, _glow;
  late Animation<Offset>  _resultSlide;

  VideoPlayerController? _vCtrl;
  ChewieController?      _chewieCtrl;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    _bugMode = widget.bugMode == 'group' ? 'group' : 'number';
    _syncSelectedBug();

    _auroraCtrl   = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _btnCtrl      = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _resultCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _pulseCtrl    = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _glowCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);

    _fade        = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _btnGlow     = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));
    _resultFade  = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));
    _pulse       = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _glow        = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _initVideo();
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _auroraCtrl.dispose(); _entranceCtrl.dispose(); _btnCtrl.dispose();
    _resultCtrl.dispose(); _pulseCtrl.dispose(); _glowCtrl.dispose();
    _targetCtrl.dispose(); _bugScrollCtrl.dispose();
    _vCtrl?.dispose(); _chewieCtrl?.dispose();
    super.dispose();
  }

  void _initVideo() {
    _vCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieCtrl = ChewieController(
            videoPlayerController: _vCtrl!,
            autoPlay: true, looping: true, showControls: false,
          );
          _videoReady = true;
        });
      });
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _loadingSenders = true);
    try {
      final r = await http.get(Uri.parse(
          '$_baseUrl/getActiveSenders?key=${widget.sessionKey}'
      )).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && d['senders'] != null && mounted)
        setState(() => _globalSenders = List<String>.from(d['senders']));
    } catch (_) {}
    finally { if (mounted) setState(() => _loadingSenders = false); }
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_bugMode == 'number' && _formatPhone(raw) == null) {
      _showAlert('Nomor Tidak Valid', 'Gunakan format: +62812xxxxxxxx'); return;
    }
    if (_bugMode == 'group' && !_validGroup(raw)) {
      _showAlert('Link Tidak Valid', 'Masukkan link grup WA yang valid.\nhttps://chat.whatsapp.com/XXX'); return;
    }
    if (_senderType == 'global' && !_canGlobal(widget.role)) {
      _showAlert('Akses Ditolak', 'Sender Global hanya untuk High Owner, Owner, High Admin & VIP!'); return;
    }
    if (_selectedBugId.isEmpty) { _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.'); return; }

    setState(() => _isSending = true);
    _resultCtrl.reset();
    HapticFeedback.mediumImpact();

    try {
      final enc = Uri.encodeComponent(raw);
      final url = Uri.parse('$_baseUrl/sendBug?key=${widget.sessionKey}&target=$enc&bug=$_selectedBugId'
          '${_senderType == "global" ? "&senderMode=global" : ""}');
      final res  = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == false)         _setResp('error',   'Session tidak valid. Login ulang.');
      else if (data['cooldown'] == true)  _setResp('warning', 'Cooldown aktif! Tunggu ${data['wait'] ?? 0}s lagi.');
      else if (data['sended'] == true)  {
        HapticFeedback.lightImpact();
        final target = _bugMode == 'group' ? 'grup target' : raw;
        _targetCtrl.clear();
        setState(() => _responseMsg = null);
        if (mounted) _showSuccessDialog(target);
      }
      else                                _setResp('error',   'Gagal kirim. Server maintenance.');
    } catch (e) {
      _setResp('error', e.toString().contains('Timeout') ? 'Request timeout!' : 'Koneksi error!');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _setResp(String t, String m) {
    if (!mounted) return;
    setState(() => _responseMsg = '$t|$m');
    _resultCtrl.forward(from: 0);
  }

  String? _formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }
  bool _validGroup(String s) => s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _showSuccessDialog(String target) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.75),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, a, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: a, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0D1120),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.success.withOpacity(0.35), width: 1.5),
            boxShadow: [
              BoxShadow(color: AppColors.success.withOpacity(0.15), blurRadius: 0, spreadRadius: 4),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // ── Ikon centang hijau ────────────────────────────────
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.success,
                boxShadow: [
                  BoxShadow(color: AppColors.success.withOpacity(0.5), blurRadius: 0, spreadRadius: 2),
                ],
              ),
              child: const Icon(Icons.check_rounded, color: Colors.white, size: 30),
            ),
            const SizedBox(height: 16),
            // ── Judul ─────────────────────────────────────────────
            const Text('Bug Terkirim', style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 18,
              fontWeight: FontWeight.w900, color: AppColors.textPrimary,
              letterSpacing: 0.5,
            )),
            const SizedBox(height: 6),
            const Text('Bug berhasil dikirim ke target:', style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 12,
              color: AppColors.textSub,
            )),
            const SizedBox(height: 12),
            // ── Nomor target ──────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: AppColors.surface.withOpacity(0.6),
                border: Border.all(color: AppColors.borderGlow),
              ),
              child: Row(children: [
                const Icon(Icons.smartphone_rounded, color: AppColors.textSub, size: 18),
                const SizedBox(width: 12),
                Text(target, style: const TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 14,
                  color: AppColors.textPrimary, fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                )),
              ]),
            ),
            const SizedBox(height: 16),
            // ── Tombol SELESAI ────────────────────────────────────
            GestureDetector(
              onTap: () => Navigator.pop(ctx),
              child: Container(
                width: double.infinity, height: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6F8A72), Color(0xFF63856D)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(color: AppColors.success.withOpacity(0.4), blurRadius: 0, offset: const Offset(0, 6)),
                  ],
                ),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('SELESAI', style: TextStyle(
                    fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.w900,
                    color: Colors.white, letterSpacing: 2,
                  )),
                  SizedBox(width: 8),
                  Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            // ── Copyright ─────────────────────────────────────────
            const Text('© Xeon Project', style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 9,
              color: AppColors.textMuted, letterSpacing: 1,
            )),
          ]),
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context, barrierDismissible: true, barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 280),
      transitionBuilder: (_, a, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: a, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.warning.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: AppColors.warning.withOpacity(0.1), blurRadius: 0)],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 56, height: 56,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: AppColors.warning.withOpacity(0.12),
                border: Border.all(color: AppColors.warning.withOpacity(0.4))),
              child: const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 26)),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontFamily: 'Orbitron', fontSize: 15,
              fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            const SizedBox(height: 9),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 13, color: AppColors.textSub, height: 1.5)),
            const SizedBox(height: 22),
            _ActionBtn(label: 'OK', colors: const [AppColors.warning, Color(0xFFE65100)],
              onTap: () => Navigator.pop(ctx), fullWidth: true),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ComicScaffold(
    backgroundColor: AppColors.bg,
    body: SafeArea(
      child: FadeTransition(
        opacity: _fade,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 38),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            _buildHeader(),
            const SizedBox(height: 16),
            _buildVideoCard(),
            const SizedBox(height: 14),
            _buildModeToggle(),
            const SizedBox(height: 12),
            _buildTargetInput(),
            const SizedBox(height: 16),
            _buildBugSelector(),
            const SizedBox(height: 16),
            _buildSenderCard(),
            if (_senderType == 'global' && _canGlobal(widget.role)) ...[
              const SizedBox(height: 12),
              _buildGlobalSenderList(),
            ],
            const SizedBox(height: 20),
            _buildSendButton(),
            if (_responseMsg != null) ...[
              const SizedBox(height: 12),
              _buildResultBanner(),
            ],
            const SizedBox(height: 10),
            Center(child: Text('XEON TEAM', style: TextStyle(letterSpacing: 3, fontSize: 9, fontWeight: FontWeight.w800, color: AppColors.textMuted))),
          ]),
        ),
      ),
    ),
  );

  Widget _buildHeader() => Row(children: [
    GestureDetector(
      onTap: () => Navigator.maybePop(context),
      child: Container(
        width: 56, height: 56,
        decoration: BoxDecoration(
          color: const Color(0xFF34383E),
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [BoxShadow(color: Color(0x33000000), offset: Offset(0, 4), blurRadius: 7)],
        ),
        child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 21),
      ),
    ),
    const SizedBox(width: 12),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('XEON BUG', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: 2.4, color: AppColors.textPrimary)),
      const SizedBox(height: 2),
      Text('${widget.username} • ${widget.role}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
    ])),
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(color: AppColors.surfaceAlt, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.border, width: 1.2)),
      child: Text(widget.expiredDate.isEmpty ? 'ACTIVE' : widget.expiredDate, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: AppColors.textSub)),
    ),
  ]);

  Widget _buildVideoCard() => _ComicPanel(
    padding: EdgeInsets.zero,
    accent: AppColors.borderActive,
    fill: const Color(0xFF090B0E),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: SizedBox(height: 210,
        child: _videoReady && _chewieCtrl != null
          ? Chewie(controller: _chewieCtrl!)
          : const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircularProgressIndicator(strokeWidth: 3, color: AppColors.surface),
              SizedBox(height: 12),
              Text('MEMUAT BANNER', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white70)),
            ])),
      ),
    ),
  );

  Widget _buildModeToggle() => Row(children: [
    Expanded(child: _ComicChoice(label: 'BUG NOMOR', icon: Icons.phone_android_rounded, active: _bugMode == 'number', onTap: () => _selectBugMode('number'))),
    const SizedBox(width: 10),
    Expanded(child: _ComicChoice(label: 'BUG GROUP', icon: Icons.groups_rounded, active: _bugMode == 'group', onTap: () => _selectBugMode('group'))),
  ]);

  Widget _buildLockedModeHeader() => _ComicPanel(
    accent: _bugMode == 'group' ? const Color(0xFF7C4DFF) : AppColors.borderActive,
    fill: (_bugMode == 'group' ? const Color(0xFF7C4DFF) : AppColors.borderActive).withOpacity(.10),
    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 13),
    child: Row(children: [
      Icon(
        _bugMode == 'group' ? Icons.groups_rounded : Icons.phone_android_rounded,
        color: _bugMode == 'group' ? const Color(0xFF9B7BFF) : AppColors.borderActive,
        size: 22,
      ),
      const SizedBox(width: 11),
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _bugMode == 'group' ? 'BUG GROUP' : 'BUG NOMOR',
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 1.2, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 3),
          Text(
            _bugMode == 'group'
                ? 'Mode khusus target group • menu nomor tidak ditampilkan'
                : 'Mode khusus target nomor • menu group tidak ditampilkan',
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textMuted),
          ),
        ],
      )),
    ]),
  );

  Widget _buildTargetInput() => _ComicPanel(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
    accent: AppColors.borderActive,
    child: TextField(
      controller: _targetCtrl,
      onChanged: (_) => setState(() {}),
      keyboardType: _bugMode == 'number' ? TextInputType.phone : TextInputType.url,
      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      decoration: InputDecoration(
        border: InputBorder.none,
        hintText: _bugMode == 'number' ? '+62812xxxxxxxx' : 'https://chat.whatsapp.com/xxxxx',
        hintStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textMuted),
        prefixIcon: Icon(_bugMode == 'number' ? Icons.phone_android_rounded : Icons.link_rounded, color: AppColors.textSub),
        suffixIcon: _targetCtrl.text.isNotEmpty ? IconButton(icon: const Icon(Icons.close_rounded), color: AppColors.textMuted, onPressed: () => setState(_targetCtrl.clear)) : null,
      ),
    ),
  );

  // The API's listBug is the source of truth. Some existing responses expose
  // category information through different field names, while older responses
  // only identify group bugs by their name/id. Never manufacture a new menu
  // list: classify the existing records and use a safe fallback for number mode.
  String _bugCategory(Map<String, dynamic> bug) {
    final explicitValues = <dynamic>[
      bug['type'], bug['bug_type'], bug['category'], bug['targetType'],
      bug['target_type'], bug['mode'], bug['target'], bug['targetMode'],
    ].where((v) => v != null).map((v) => v.toString().trim().toLowerCase()).where((v) => v.isNotEmpty).toList();

    final bool? explicitGroup = _boolValue(bug['isGroup']) ?? _boolValue(bug['is_group']) ?? _boolValue(bug['group']);
    if (explicitGroup == true) return 'group';
    if (explicitGroup == false) return 'number';

    final metadata = explicitValues.join(' ');
    if (_containsGroupToken(metadata)) return 'group';
    if (_containsNumberToken(metadata)) return 'number';

    final name = '${bug['bug_name'] ?? ''} ${bug['name'] ?? ''} ${bug['bug_id'] ?? ''}'.toLowerCase();
    if (_containsGroupToken(name)) return 'group';

    // Existing number menus historically had no category metadata. Treat an
    // unclassified existing record as number rather than making the UI show
    // "0 MENU". The record itself is never altered or duplicated.
    return 'number';
  }

  bool? _boolValue(dynamic value) {
    if (value is bool) return value;
    if (value == null) return null;
    final s = value.toString().trim().toLowerCase();
    if (s == 'true' || s == '1' || s == 'yes' || s == 'group') return true;
    if (s == 'false' || s == '0' || s == 'no' || s == 'number' || s == 'nomor') return false;
    return null;
  }

  bool _containsGroupToken(String value) => value.contains('group') || value.contains('grup') || value.contains('groupwa');
  bool _containsNumberToken(String value) => value.contains('number') || value.contains('nomor') || value.contains('phone') || value.contains('private');

  List<Map<String, dynamic>> get _visibleBugs => widget.listBug
      .where((bug) => _bugCategory(bug) == _bugMode)
      .toList(growable: false);

  void _syncSelectedBug() {
    final visible = _visibleBugs;
    if (visible.isEmpty) {
      _selectedBugId = '';
      return;
    }
    final currentExists = visible.any((b) => (b['bug_id'] ?? '').toString() == _selectedBugId);
    if (!currentExists) _selectedBugId = (visible.first['bug_id'] ?? '').toString();
  }

  void _selectBugMode(String mode) {
    if (mode != 'number' && mode != 'group') return;
    if (_bugMode == mode) return;
    setState(() {
      _bugMode = mode;
      _syncSelectedBug();
      _responseMsg = null;
    });
    _bugScrollCtrl.jumpTo(0);
  }

  Widget _buildBugSelector() => _ComicPanel(
    accent: AppColors.borderActive,
    fill: AppColors.surfaceAlt,
    padding: const EdgeInsets.fromLTRB(14, 14, 0, 12),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        _ComicIcon(icon: Icons.bug_report_rounded, color: AppColors.danger, small: true),
        const SizedBox(width: 10),
        const Text('PILIH BUG', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.5, color: AppColors.textPrimary)),
        const Spacer(),
        Padding(padding: const EdgeInsets.only(right: 14), child: Text('${_visibleBugs.length} MENU', style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: AppColors.textMuted))),
      ]),
      const SizedBox(height: 14),
      SizedBox(height: 180, child: ListView.separated(
        controller: _bugScrollCtrl,
        padding: const EdgeInsets.only(right: 14),
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: _visibleBugs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final b = _visibleBugs[i];
          final id = b['bug_id'] ?? '';
          final name = b['bug_name'] ?? 'Bug ${i + 1}';
          final active = id == _selectedBugId;
          return _BugCard3D(
            name: name,
            id: id,
            active: active,
            onTap: () => setState(() => _selectedBugId = id),
          );
        },
      )),
      const SizedBox(height: 8),
      Center(child: Container(width: 48, height: 7, decoration: BoxDecoration(color: AppColors.borderActive, borderRadius: BorderRadius.circular(99)))),
    ]),
  );

  Widget _buildSenderCard() {
    final canGlobal = _canGlobal(widget.role);
    return _ComicPanel(
      accent: AppColors.borderActive,
      fill: AppColors.surfaceAlt,
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _ComicIcon(icon: Icons.sensors_rounded, color: AppColors.borderActive, small: true),
          const SizedBox(width: 10),
          const Expanded(child: Text('PILIH SENDER', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.3))),
          Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: _senderType == 'global' ? AppColors.success.withOpacity(.12) : AppColors.danger.withOpacity(.10), borderRadius: BorderRadius.circular(15), border: Border.all(color: _senderType == 'global' ? AppColors.success : AppColors.danger.withOpacity(.4))), child: Text(_senderType == 'global' ? '${_globalSenders.length} ONLINE' : 'PRIVATE', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: _senderType == 'global' ? AppColors.success : AppColors.danger))),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: GestureDetector(onTap: () => setState(() => _senderType = 'private'), child: _ComicModeCard(label: 'Private', sub: 'Sender pribadi', icon: Icons.person_rounded, active: _senderType == 'private', color: AppColors.borderActive))),
          const SizedBox(width: 12),
          Expanded(child: Opacity(opacity: canGlobal ? 1 : .5, child: GestureDetector(onTap: () { if (!canGlobal) { _showAlert('Akses Ditolak', 'Role kamu belum memiliki akses sender global.'); return; } setState(() => _senderType = 'global'); if (_globalSenders.isEmpty) _loadGlobalSenders(); }, child: _ComicModeCard(label: 'Global', sub: _loadingSenders ? 'Memuat...' : '${_globalSenders.length} sender aktif', icon: Icons.public_rounded, active: _senderType == 'global', color: AppColors.success)))),
        ]),
        const SizedBox(height: 14),
        const Text('Sisa kirim global hari ini mengikuti limit akun aktif.', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textMuted)),
      ]),
    );
  }

  Widget _buildGlobalSenderList() => _ComicPanel(
    accent: AppColors.success,
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Icon(Icons.people_alt_rounded, color: AppColors.success, size: 19),
        const SizedBox(width: 8),
        const Expanded(child: Text('SENDER GLOBAL AKTIF', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.textPrimary))),
        IconButton(onPressed: _loadGlobalSenders, icon: const Icon(Icons.refresh_rounded), color: AppColors.success),
      ]),
      const SizedBox(height: 10),
      if (_loadingSenders) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: AppColors.success)))
      else if (_globalSenders.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Belum ada sender global aktif.', style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.textMuted)))
      else _buildSenderListCompact(),
    ]),
  );

  Widget _buildSenderListCompact() {
    final first = _globalSenders.first;
    final more = _globalSenders.length - 1;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 18), const SizedBox(width: 8), Expanded(child: Text(first, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)))]),
      if (more > 0) Padding(padding: const EdgeInsets.only(top: 8), child: TextButton(onPressed: _showAllSenders, child: Text('Lihat $more sender lainnya'))),
    ]);
  }

  void _showAllSenders() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _ComicPanel(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 30),
        accent: AppColors.success,
        child: SafeArea(top: false, child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('SEMUA SENDER GLOBAL', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
          const SizedBox(height: 14),
          ..._globalSenders.asMap().entries.map((e) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _ComicPanel(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), accent: AppColors.success, child: Row(children: [const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 18), const SizedBox(width: 10), Expanded(child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w700))), Text('#${e.key + 1}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.textMuted))])))),
        ])),
      ),
    );
  }

  Widget _buildSendButton() => _SendBugButton3D(
    loading: _isSending,
    onTap: _isSending ? null : _sendBug,
  );

  Widget _buildResultBanner() {
    final parts = _responseMsg!.split('|');
    final type = parts.first;
    final msg = parts.length > 1 ? parts[1] : '';
    final color = type == 'success' ? AppColors.success : type == 'warning' ? AppColors.warning : AppColors.danger;
    return FadeTransition(opacity: _resultFade, child: _ComicPanel(accent: color, fill: color.withOpacity(.08), padding: const EdgeInsets.all(15), child: Row(children: [Icon(type == 'warning' ? Icons.warning_rounded : Icons.info_rounded, color: color), const SizedBox(width: 10), Expanded(child: Text(msg, style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.textPrimary)))])));
  }
}

// ── Reusable Comic 3D UI ─────────────────────────────────────
class _ActionBtn extends StatelessWidget {
  final String label;
  final List<Color> colors;
  final VoidCallback? onTap;
  final bool fullWidth;

  const _ActionBtn({
    required this.label,
    required this.colors,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    final background = colors.isNotEmpty ? colors.first : AppColors.primary;
    final child = Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          height: 52,
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.primaryDark.withOpacity(.45)),
            boxShadow: const [
              BoxShadow(color: Color(0x1F000000), offset: Offset(0, 4), blurRadius: 0),
            ],
          ),
          child: Center(
            child: Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900),
            ),
          ),
        ),
      ),
    );
    return fullWidth ? SizedBox(width: double.infinity, child: child) : child;
  }
}

class _ComicPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color accent;
  final Color? fill;
  const _ComicPanel({required this.child, required this.accent, this.fill, this.padding = const EdgeInsets.all(14)});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.only(bottom: 5),
    decoration: BoxDecoration(
      color: const Color(0xFF2B2926),
      borderRadius: BorderRadius.circular(22),
      boxShadow: const [BoxShadow(color: Color(0x18000000), offset: Offset(0, 5), blurRadius: 8)],
    ),
    child: Container(
      padding: padding,
      decoration: BoxDecoration(
        color: fill ?? AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF2B2926), width: 1.4),
      ),
      child: child,
    ),
  );
}

class _ComicSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;
  final Widget? trailing;
  const _ComicSection({required this.title, required this.icon, required this.child, this.trailing});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(padding: const EdgeInsets.only(left: 4, bottom: 9), child: Row(children: [Icon(icon, size: 18, color: AppColors.cyan), const SizedBox(width: 8), Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.textPrimary)), const Spacer(), if (trailing != null) trailing!])),
    child,
  ]);
}

class _ComicIcon extends StatelessWidget {
  final IconData icon; final Color color; final bool small;
  const _ComicIcon({required this.icon, required this.color, this.small = false});
  @override
  Widget build(BuildContext context) { final s = small ? 42.0 : 58.0; return Container(width: s, height: s, decoration: BoxDecoration(color: color.withOpacity(.16), borderRadius: BorderRadius.circular(small ? 14 : 20), border: Border.all(color: color.withOpacity(.55), width: 1.2)), child: Icon(icon, color: color, size: small ? 22 : 30)); }
}

class _ComicBadge extends StatelessWidget {
  final String label; final Color color;
  const _ComicBadge({required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(.45))), child: Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: color)));
}

class _ComicChoice extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  const _ComicChoice({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  @override
  State<_ComicChoice> createState() => _ComicChoiceState();
}

class _ComicChoiceState extends State<_ComicChoice> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const depth = 4.0;
    final bg = widget.active ? const Color(0xFF1A1A1A) : AppColors.card;
    final fg = widget.active ? Colors.white : AppColors.textPrimary;
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 80),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          margin: EdgeInsets.only(top: _down ? depth : 0, bottom: _down ? 0 : depth),
          decoration: BoxDecoration(
            color: AppColors.borderActive,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.borderActive, width: 2.2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(widget.icon, color: fg, size: 18),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    widget.label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 11,
                      letterSpacing: 0.5,
                      fontWeight: FontWeight.w900,
                      color: fg,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ComicModeCard extends StatelessWidget {
  final String label, sub; final IconData icon; final bool active; final Color color;
  const _ComicModeCard({required this.label, required this.sub, required this.icon, required this.active, required this.color});
  @override
  Widget build(BuildContext context) => _ComicPanel(accent: active ? color : AppColors.borderActive, fill: active ? color.withOpacity(.08) : AppColors.surface, padding: const EdgeInsets.all(14), child: Column(children: [Icon(icon, color: active ? color : AppColors.textMuted), const SizedBox(height: 7), Text(label, style: TextStyle(fontWeight: FontWeight.w900, color: active ? color : AppColors.textPrimary)), const SizedBox(height: 3), Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textMuted))]));
}

/// Bug card 3D — press naik-turun seperti referensi AzuraX
class _BugCard3D extends StatefulWidget {
  final String name, id;
  final bool active;
  final VoidCallback onTap;
  const _BugCard3D({
    required this.name,
    required this.id,
    required this.active,
    required this.onTap,
  });

  @override
  State<_BugCard3D> createState() => _BugCard3DState();
}

class _BugCard3DState extends State<_BugCard3D> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const depth = 5.0;
    final red = widget.active ? const Color(0xFFD44A4A) : const Color(0xFFC04545);
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.96 : (widget.active ? 1.0 : 0.97),
        duration: const Duration(milliseconds: 90),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          width: 200,
          margin: EdgeInsets.only(
            top: _down ? depth : 0,
            bottom: _down ? 0 : depth,
            right: 4,
          ),
          decoration: BoxDecoration(
            color: const Color(0xFF6B2020),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: red,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.borderActive, width: 2.4),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 22),
                    const Spacer(),
                    if (widget.active)
                      const Icon(Icons.check_circle_rounded, color: Color(0xFF5ECF7A), size: 26),
                  ],
                ),
                const Spacer(),
                Text(
                  widget.name.toUpperCase(),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    widget.id.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      color: Colors.white70,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SendBugButton3D extends StatefulWidget {
  final bool loading;
  final VoidCallback? onTap;
  const _SendBugButton3D({required this.loading, this.onTap});

  @override
  State<_SendBugButton3D> createState() => _SendBugButton3DState();
}

class _SendBugButton3DState extends State<_SendBugButton3D> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const depth = 5.0;
    final green = widget.loading ? AppColors.successDim : const Color(0xFF2EBB5E);
    return GestureDetector(
      onTapDown: widget.onTap == null ? null : (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 90),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          margin: EdgeInsets.only(top: _down ? depth : 0, bottom: _down ? 0 : depth),
          decoration: BoxDecoration(
            color: const Color(0xFF1A6B38),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Container(
            height: 58,
            decoration: BoxDecoration(
              color: green,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.borderActive, width: 2.2),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: widget.loading
                  ? const [
                      SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white),
                      ),
                      SizedBox(width: 12),
                      Text(
                        'MEMPROSES...',
                        style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white),
                      ),
                    ]
                  : const [
                      Icon(Icons.play_arrow_rounded, color: Colors.white, size: 26),
                      SizedBox(width: 8),
                      Text(
                        'KIRIM BUG  >>',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          color: Colors.white,
                        ),
                      ),
                    ],
            ),
          ),
        ),
      ),
    );
  }
}


class _BugModeEntry extends StatefulWidget {
  final String title, subtitle;
  final IconData icon;
  final Color accent;
  final VoidCallback onTap;

  const _BugModeEntry({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.onTap,
  });

  @override
  State<_BugModeEntry> createState() => _BugModeEntryState();
}

class _BugModeEntryState extends State<_BugModeEntry> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        transform: Matrix4.translationValues(0, _pressed ? 3 : 0, 0),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: AppColors.surfaceAlt,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: widget.accent.withOpacity(.65), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.20),
              blurRadius: _pressed ? 2 : 8,
              offset: Offset(0, _pressed ? 2 : 6),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: widget.accent.withOpacity(.14),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: widget.accent.withOpacity(.45)),
            ),
            child: Icon(widget.icon, color: widget.accent, size: 28),
          ),
          const SizedBox(width: 15),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, letterSpacing: 1.2, color: AppColors.textPrimary)),
              const SizedBox(height: 5),
              Text(widget.subtitle, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textMuted)),
            ],
          )),
          Icon(Icons.arrow_forward_ios_rounded, size: 17, color: widget.accent),
        ]),
      ),
    );
  }
}
