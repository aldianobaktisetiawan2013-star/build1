// COMIC_MATTE_UI_PASS: all screens inherit the shared 3D Comic Matte component system.
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'main.dart';
import 'splash.dart';
import 'design_system/comic_page.dart';

const String baseUrl = 'http://kontolilegalzyro.rexypediaa.biz.id:3055';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userCtrl  = TextEditingController();
  final passCtrl  = TextEditingController();
  final _formKey  = GlobalKey<FormState>();

  bool   _isLoading   = false;
  bool   _obscurePass = true;
  String? _androidId;
  String? _errorMsg;

  late AnimationController _auroraCtrl, _entranceCtrl, _logoCtrl, _btnCtrl, _shakeCtrl, _pulseCtrl;
  late Animation<double> _fade, _logoGlow, _btnPulse, _shake, _pulse;
  late Animation<Offset>  _slide;

  @override
  void initState() {
    super.initState();

    _auroraCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _logoCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))..repeat(reverse: true);
    _btnCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 480));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);

    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.07), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));
    _logoGlow = Tween<double>(begin: 0.25, end: 1.0)
        .animate(CurvedAnimation(parent: _logoCtrl, curve: Curves.easeInOut));
    _btnPulse = Tween<double>(begin: 0.4, end: 1.0)
        .animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));
    _shake = Tween<double>(begin: -1, end: 1)
        .animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticIn));
    _pulse = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _getDeviceId();
    Future.delayed(const Duration(milliseconds: 160), () {
      if (mounted) _entranceCtrl.forward();
    });
  }

  @override
  void dispose() {
    userCtrl.dispose(); passCtrl.dispose();
    _auroraCtrl.dispose(); _entranceCtrl.dispose(); _logoCtrl.dispose();
    _btnCtrl.dispose(); _shakeCtrl.dispose(); _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _getDeviceId() async {
    try {
      final info = DeviceInfoPlugin();
      final android = await info.androidInfo;
      if (mounted) setState(() => _androidId = android.id);
      await _tryAutoLogin();
    } catch (_) {
      await _tryAutoLogin();
    }
  }

  Future<void> _tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey  = prefs.getString('key');
    if (savedUser == null || savedPass == null || savedKey == null) return;
    try {
      final aid = _androidId ?? 'unknown';
      final res = await http.get(Uri.parse(
          '$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$aid&key=$savedKey'
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SplashScreen(
          username:    savedUser,
          password:    savedPass,
          role:        data['role']        ?? 'member',
          expiredDate: data['expiredDate'] ?? '-',
          sessionKey:  data['key']         ?? savedKey,
          listBug:     _parseList(data['listBug']),
          listDoos:    _parseList(data['listDDoS']),
          news:        _parseList(data['news']),
        )));
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _doLogin() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() { _isLoading = true; _errorMsg = null; });

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    try {
      final resp = await http.post(
        Uri.parse('$baseUrl/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': _androidId ?? 'unknown',
        },
      ).timeout(const Duration(seconds: 12));

      final data = jsonDecode(resp.body);

      if (data['expired'] == true) {
        setState(() => _errorMsg = 'Masa akses habis. Silakan perpanjang.');
        _shakeCtrl.forward(from: 0);
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') || msg.contains('another')) {
          setState(() => _errorMsg = 'Akun sedang login di perangkat lain.');
        } else {
          setState(() => _errorMsg = 'Username atau password salah.');
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', username);
        await prefs.setString('password', password);
        await prefs.setString('key',      data['key'] ?? '');

        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SplashScreen(
          username:    username,
          password:    password,
          role:        data['role']        ?? 'member',
          expiredDate: data['expiredDate'] ?? '-',
          sessionKey:  data['key']         ?? '',
          listBug:     _parseList(data['listBug']),
          listDoos:    _parseList(data['listDDoS']),
          news:        _parseList(data['news']),
        )));
      }
    } catch (e) {
      setState(() => _errorMsg = 'Koneksi gagal. Periksa internet.');
      _shakeCtrl.forward(from: 0);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) await launchUrl(u, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => ComicScaffold(
    backgroundColor: AppColors.bg,
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 32),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildBrand(),
                    const SizedBox(height: 28),
                    _buildLoginCard(),
                    const SizedBox(height: 22),
                    _buildFooter(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );

  Widget _buildBrand() => Column(
    children: [
      // Dimensional logo plate
      Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          color: AppColors.dustyBlue.withOpacity(0.9),
          borderRadius: BorderRadius.circular(28),
          boxShadow: [
            BoxShadow(
              color: AppColors.borderActive.withOpacity(0.18),
              offset: const Offset(0, 6),
              blurRadius: 0,
            ),
          ],
        ),
        padding: const EdgeInsets.only(bottom: 5),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.borderActive, width: 2.4),
          ),
          padding: const EdgeInsets.all(10),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
          ),
        ),
      ),
      const SizedBox(height: 18),
      const Text(
        'Xeon',
        style: TextStyle(
          fontSize: 34,
          fontWeight: FontWeight.w900,
          color: AppColors.textPrimary,
          letterSpacing: 0.4,
          height: 1.05,
        ),
      ),
      const SizedBox(height: 6),
      Text(
        'Masuk untuk melanjutkan',
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppColors.textSub,
        ),
      ),
    ],
  );

  Widget _buildLoginCard() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.dustyBlue.withOpacity(0.85),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.borderActive.withOpacity(0.12),
            offset: const Offset(0, 6),
            blurRadius: 12,
          ),
        ],
      ),
      padding: const EdgeInsets.only(bottom: 5),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.borderActive, width: 2.2),
        ),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  _ComicIcon(icon: Icons.lock_rounded, color: AppColors.dustyBlue),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Login akun',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: AppColors.textPrimary,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Masukkan username dan password kamu',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppColors.textSub,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 22),
              if (_errorMsg != null) ...[
                _ErrorBox(message: _errorMsg!),
                const SizedBox(height: 14),
              ],
              _SimpleComicField(
                controller: userCtrl,
                label: 'Username',
                hint: 'Masukkan username',
                icon: Icons.person_rounded,
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Username wajib diisi' : null,
              ),
              const SizedBox(height: 14),
              _SimpleComicField(
                controller: passCtrl,
                label: 'Password',
                hint: 'Masukkan password',
                icon: Icons.key_rounded,
                obscure: _obscurePass,
                suffix: IconButton(
                  onPressed: () => setState(() => _obscurePass = !_obscurePass),
                  icon: Icon(
                    _obscurePass
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: AppColors.textSub,
                  ),
                ),
                validator: (v) =>
                    (v == null || v.isEmpty) ? 'Password wajib diisi' : null,
                onSubmit: (_) => _doLogin(),
              ),
              const SizedBox(height: 22),
              _ComicActionButton(
                loading: _isLoading,
                onTap: _isLoading ? null : _doLogin,
                label: _isLoading ? 'Memeriksa akun...' : 'Masuk sekarang',
                icon: _isLoading ? null : Icons.login_rounded,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() => Column(
    children: [
      const Text(
        'Belum punya akun?',
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: AppColors.textSub,
        ),
      ),
      const SizedBox(height: 10),
      TextButton.icon(
        onPressed: () => _launch('https://t.me/krizoficialll'),
        icon: const Icon(Icons.send_rounded, size: 18, color: AppColors.dustyBlue),
        label: const Text(
          'Hubungi admin',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: AppColors.dustyBlue,
          ),
        ),
      ),
    ],
  );
}

class _ComicIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _ComicIcon({required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.45), width: 1.6),
      ),
      child: Icon(icon, color: color, size: 22),
    );
  }
}

class _ErrorBox extends StatelessWidget {
  final String message;
  const _ErrorBox({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: AppColors.danger.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.danger.withOpacity(0.4), width: 1.6),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded, color: AppColors.danger, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.danger,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SimpleComicField extends StatefulWidget {
  final TextEditingController controller;
  final String label, hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;
  final void Function(String)? onSubmit;

  const _SimpleComicField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.validator,
    this.onSubmit,
  });

  @override
  State<_SimpleComicField> createState() => _SimpleComicFieldState();
}

class _SimpleComicFieldState extends State<_SimpleComicField> {
  bool focused = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: focused ? AppColors.dustyBlue : AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Focus(
          onFocusChange: (v) => setState(() => focused = v),
          child: TextFormField(
            controller: widget.controller,
            obscureText: widget.obscure,
            validator: widget.validator,
            onFieldSubmitted: widget.onSubmit,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
            ),
            decoration: InputDecoration(
              hintText: widget.hint,
              prefixIcon: Icon(
                widget.icon,
                color: focused ? AppColors.dustyBlue : AppColors.textSub,
              ),
              suffixIcon: widget.suffix,
              filled: true,
              fillColor: AppColors.surfaceAlt,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppColors.border, width: 1.8),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppColors.border, width: 1.8),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppColors.dustyBlue, width: 2.2),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppColors.danger, width: 1.8),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _ComicActionButton extends StatefulWidget {
  final bool loading;
  final VoidCallback? onTap;
  final String label;
  final IconData? icon;

  const _ComicActionButton({
    required this.loading,
    required this.onTap,
    required this.label,
    this.icon,
  });

  @override
  State<_ComicActionButton> createState() => _ComicActionButtonState();
}

class _ComicActionButtonState extends State<_ComicActionButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const depth = 4.0;
    final disabled = widget.loading || widget.onTap == null;
    return GestureDetector(
      onTapDown: disabled ? null : (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: disabled ? null : widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 90),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          margin: EdgeInsets.only(top: _down ? depth : 0, bottom: _down ? 0 : depth),
          height: 54,
          decoration: BoxDecoration(
            color: disabled
                ? AppColors.border
                : AppColors.dustyBlueDim.withOpacity(0.95),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Container(
            decoration: BoxDecoration(
              color: disabled ? AppColors.border : AppColors.dustyBlue,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: AppColors.borderActive.withOpacity(0.9),
                width: 2.0,
              ),
            ),
            child: Center(
              child: widget.loading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (widget.icon != null) ...[
                          Icon(widget.icon, color: Colors.white, size: 20),
                          const SizedBox(width: 9),
                        ],
                        Text(
                          widget.label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
