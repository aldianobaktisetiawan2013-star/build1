import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

import 'main.dart';

/// Reusable 3D-comic press feedback used by Story controls.
class XeonPressable extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final BorderRadius borderRadius;

  const XeonPressable({
    super.key,
    required this.child,
    this.onTap,
    this.borderRadius = const BorderRadius.all(
      Radius.circular(18),
    ),
  });

  @override
  State<XeonPressable> createState() => _XeonPressableState();
}

class _XeonPressableState extends State<XeonPressable> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (mounted) {
      setState(() => _pressed = value);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      onTapDown: (_) => _setPressed(true),
      onTapUp: (_) => _setPressed(false),
      onTapCancel: () => _setPressed(false),
      child: AnimatedScale(
        scale: _pressed ? .965 : 1,
        duration: const Duration(milliseconds: 90),
        curve: Curves.easeOut,
        child: AnimatedSlide(
          offset: _pressed ? const Offset(0, .018) : Offset.zero,
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOutBack,
          child: widget.child,
        ),
      ),
    );
  }
}

class XeonStoryComposerResult {
  final String type;
  final String mediaPath;
  final String text;
  final String caption;
  final String backgroundType;
  final String backgroundPath;

  const XeonStoryComposerResult({
    required this.type,
    required this.mediaPath,
    required this.text,
    required this.caption,
    required this.backgroundType,
    required this.backgroundPath,
  });
}

class XeonStoryComposer extends StatefulWidget {
  final String type;

  const XeonStoryComposer({
    super.key,
    required this.type,
  });

  @override
  State<XeonStoryComposer> createState() => _XeonStoryComposerState();
}

class _XeonStoryComposerState extends State<XeonStoryComposer> {
  final ImagePicker _picker = ImagePicker();
  final _caption = TextEditingController();
  final _text = TextEditingController();

  String _mediaPath = '';
  String _backgroundType = '';
  String _backgroundPath = '';
  bool _busy = false;

  @override
  void dispose() {
    _caption.dispose();
    _text.dispose();
    super.dispose();
  }

  Future<String> _copyToApp(
    XFile source,
    String prefix,
  ) async {
    final dir = await getApplicationDocumentsDirectory();

    final dot = source.path.lastIndexOf('.');
    final ext = dot > -1 ? source.path.substring(dot) : '';

    final target = File(
      '${dir.path}/${prefix}_${DateTime.now().microsecondsSinceEpoch}$ext',
    );

    await File(source.path).copy(target.path);

    return target.path;
  }

  Future<void> _pickStoryMedia() async {
    setState(() => _busy = true);

    try {
      final file = widget.type == 'video'
          ? await _picker.pickVideo(
              source: ImageSource.gallery,
            )
          : await _picker.pickImage(
              source: ImageSource.gallery,
              imageQuality: 92,
            );

      if (file != null && mounted) {
        final path = await _copyToApp(
          file,
          'xeon_story',
        );

        setState(() => _mediaPath = path);
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  Future<void> _pickBackground() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => const _BackgroundChoiceSheet(),
    );

    if (choice == null || !mounted) {
      return;
    }

    setState(() => _busy = true);

    try {
      final file = choice == 'video'
          ? await _picker.pickVideo(
              source: ImageSource.gallery,
            )
          : await _picker.pickImage(
              source: ImageSource.gallery,
              imageQuality: 92,
            );

      if (file != null && mounted) {
        final path = await _copyToApp(
          file,
          'xeon_story_bg',
        );

        setState(() {
          _backgroundType = choice;
          _backgroundPath = path;
        });
      }
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  void _publish() {
    if (_busy) {
      return;
    }

    if (widget.type != 'text' && _mediaPath.isEmpty) {
      _snack('Pilih media Story terlebih dahulu.');
      return;
    }

    if (widget.type == 'text' && _text.text.trim().isEmpty) {
      _snack('Tulis isi Story terlebih dahulu.');
      return;
    }

    Navigator.of(context).pop(
      XeonStoryComposerResult(
        type: widget.type,
        mediaPath: _mediaPath,
        text: _text.text.trim(),
        caption: _caption.text.trim(),
        backgroundType: _backgroundType,
        backgroundPath: _backgroundPath,
      ),
    );
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final title = widget.type == 'video'
        ? 'VIDEO STORY'
        : widget.type == 'image'
            ? 'PHOTO STORY'
            : 'TEXT STORY';

    return Material(
      color: AppColors.surface,
      borderRadius: BorderRadius.circular(28),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            18,
            16,
            18,
            18,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.borderActive,
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.cardHover,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: AppColors.borderActive,
                          width: 1.8,
                        ),
                      ),
                      child: Icon(
                        widget.type == 'video'
                            ? Icons.videocam_rounded
                            : widget.type == 'image'
                                ? Icons.photo_rounded
                                : Icons.text_fields_rounded,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w800,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (widget.type == 'text') ...[
                  TextField(
                    controller: _text,
                    maxLines: 5,
                    maxLength: 500,
                    decoration: _decoration(
                      'Tulis cerita kamu...',
                    ),
                  ),
                  const SizedBox(height: 10),
                  XeonPressable(
                    onTap: _pickBackground,
                    child: _pickerTile(
                      Icons.wallpaper_rounded,
                      _backgroundPath.isEmpty
                          ? 'Pilih background foto/video'
                          : 'Background dipilih',
                    ),
                  ),
                ] else ...[
                  XeonPressable(
                    onTap: _pickStoryMedia,
                    child: _mediaPreview(),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Media Story menjadi tampilan utama agar tetap penuh dan jelas.',
                    style: TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 11,
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                TextField(
                  controller: _caption,
                  maxLines: 2,
                  maxLength: 180,
                  decoration: _decoration(
                    'Caption (opsional)',
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: XeonPressable(
                    onTap: _publish,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        vertical: 15,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.sageGreen,
                        borderRadius: BorderRadius.circular(17),
                        border: Border.all(
                          color: AppColors.borderActive,
                          width: 2,
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: AppColors.textPrimary,
                            offset: Offset(2, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.publish_rounded,
                            color: Colors.white,
                            size: 19,
                          ),
                          SizedBox(width: 8),
                          Text(
                            'PUBLIKASIKAN STORY',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _decoration(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: AppColors.card,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: AppColors.border,
        ),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: AppColors.border,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(
          color: AppColors.borderActive,
          width: 2,
        ),
      ),
    );
  }

  Widget _pickerTile(
    IconData icon,
    String label,
  ) {
    return Container(
      height: 64,
      padding: const EdgeInsets.symmetric(
        horizontal: 14,
      ),
      decoration: BoxDecoration(
        color: AppColors.cardHover,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(
          color: AppColors.borderActive,
          width: 1.5,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: AppColors.textPrimary,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
          ),
          const Icon(
            Icons.chevron_right_rounded,
            color: AppColors.textMuted,
          ),
        ],
      ),
    );
  }

  Widget _mediaPreview() {
    if (_mediaPath.isEmpty) {
      return _pickerTile(
        widget.type == 'video'
            ? Icons.video_library_rounded
            : Icons.add_photo_alternate_rounded,
        'Pilih ${widget.type == 'video' ? 'video' : 'foto'} dari galeri',
      );
    }

    if (widget.type == 'video') {
      return Container(
        height: 170,
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: AppColors.borderActive,
            width: 2,
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.check_circle_rounded,
                color: AppColors.sageGreen,
                size: 40,
              ),
              SizedBox(height: 8),
              Text(
                'Video siap dipublikasikan',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Image.file(
        File(_mediaPath),
        height: 190,
        width: double.infinity,
        fit: BoxFit.cover,
      ),
    );
  }
}

class _BackgroundChoiceSheet extends StatelessWidget {
  const _BackgroundChoiceSheet();

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: AppColors.borderActive,
            width: 2,
          ),
          boxShadow: const [
            BoxShadow(
              color: AppColors.textPrimary,
              offset: Offset(3, 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: XeonPressable(
                onTap: () => Navigator.pop(
                  context,
                  'image',
                ),
                child: _item(
                  Icons.photo_rounded,
                  'FOTO',
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: XeonPressable(
                onTap: () => Navigator.pop(
                  context,
                  'video',
                ),
                child: _item(
                  Icons.videocam_rounded,
                  'VIDEO',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _item(
    IconData icon,
    String text,
  ) {
    return Container(
      height: 90,
      decoration: BoxDecoration(
        color: AppColors.cardHover,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: AppColors.border,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: AppColors.textPrimary,
          ),
          const SizedBox(height: 7),
          Text(
            text,
            style: const TextStyle(
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}

class XeonStoryViewer extends StatefulWidget {
  final List<Map<String, String>> stories;
  final int initialIndex;
  final File? profileImage;
  final String owner;
  final VoidCallback? onViewed;

  const XeonStoryViewer({
    super.key,
    required this.stories,
    this.initialIndex = 0,
    this.profileImage,
    required this.owner,
    this.onViewed,
  });

  @override
  State<XeonStoryViewer> createState() => _XeonStoryViewerState();
}

class _XeonStoryViewerState extends State<XeonStoryViewer>
    with TickerProviderStateMixin {
  late int _index;

  Timer? _timer;
  AnimationController? _progress;
  VideoPlayerController? _video;

  @override
  void initState() {
    super.initState();

    _index = widget.stories.isEmpty
        ? 0
        : widget.initialIndex
            .clamp(
              0,
              widget.stories.length - 1,
            )
            .toInt();

    _loadCurrent();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _progress?.dispose();
    _video?.dispose();
    super.dispose();
  }

  Future<void> _loadCurrent() async {
    _timer?.cancel();
    _progress?.dispose();

    await _video?.dispose();
    _video = null;

    if (!mounted || widget.stories.isEmpty) {
      return;
    }

    final story = widget.stories[_index];

    final type =
        (story['backgroundType'] ?? '').isNotEmpty
            ? story['backgroundType']!
            : story['type'] ?? 'text';

    final path =
        (story['backgroundPath'] ?? '').isNotEmpty
            ? story['backgroundPath']!
            : story['path'] ?? '';

    if (type == 'video' && File(path).existsSync()) {
      final controller = VideoPlayerController.file(
        File(path),
      );

      _video = controller;

      try {
        await controller.initialize();
        await controller.play();

        if (!mounted) {
          return;
        }

        final duration = controller.value.duration > Duration.zero
            ? controller.value.duration
            : const Duration(seconds: 15);

        _startProgress(duration);

        setState(() {});

        controller.addListener(_onVideoTick);
      } catch (_) {
        _startProgress(
          const Duration(seconds: 15),
        );
      }
    } else {
      _startProgress(
        story['type'] == 'text'
            ? const Duration(seconds: 5)
            : const Duration(seconds: 5),
      );
    }

    widget.onViewed?.call();
  }

  void _onVideoTick() {
    final controller = _video;

    if (controller == null || !mounted) {
      return;
    }

    if (controller.value.isInitialized &&
        controller.value.duration > Duration.zero &&
        controller.value.position >= controller.value.duration &&
        !controller.value.isPlaying) {
      _next();
    }
  }

  void _startProgress(Duration duration) {
    if (!mounted) {
      return;
    }

    _progress = AnimationController(
      vsync: this,
      duration: duration,
    )
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          _next();
        }
      })
      ..forward();

    setState(() {});
  }

  void _next() {
    if (!mounted) {
      return;
    }

    if (_index < widget.stories.length - 1) {
      setState(() => _index++);
      _loadCurrent();
    } else {
      Navigator.pop(context);
    }
  }

  void _previous() {
    if (!mounted) {
      return;
    }

    if (_index > 0) {
      setState(() => _index--);
      _loadCurrent();
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.stories.isEmpty) {
      return const SizedBox.shrink();
    }

    final story = widget.stories[_index];

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          fit: StackFit.expand,
          children: [
            Positioned.fill(
              child: _background(story),
            ),
            Positioned(
              left: 12,
              right: 12,
              top: 8,
              child: Column(
                children: [
                  _progressBars(),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 18,
                        backgroundImage: widget.profileImage != null
                            ? FileImage(
                                widget.profileImage!,
                              )
                            : null,
                        child: widget.profileImage == null
                            ? const Icon(
                                Icons.person_rounded,
                              )
                            : null,
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          widget.owner,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      Text(
                        '${_index + 1}/${widget.stories.length}',
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 11,
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(
                          Icons.close_rounded,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Positioned.fill(
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: _previous,
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: _next,
                    ),
                  ),
                ],
              ),
            ),
            if ((story['caption'] ?? '').isNotEmpty)
              Positioned(
                left: 24,
                right: 24,
                bottom: 28,
                child: Text(
                  story['caption']!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _progressBars() {
    return Row(
      children: List.generate(
        widget.stories.length,
        (i) {
          final value = i < _index
              ? 1.0
              : i == _index
                  ? (_progress?.value ?? 0.0)
                  : 0.0;

          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 2,
              ),
              child: AnimatedBuilder(
                animation: _progress ??
                    const AlwaysStoppedAnimation<double>(0),
                builder: (_, __) {
                  return LinearProgressIndicator(
                    value: value,
                    minHeight: 3,
                    backgroundColor:
                        Colors.white.withOpacity(.28),
                    valueColor:
                        const AlwaysStoppedAnimation<Color>(
                      Colors.white,
                    ),
                  );
                },
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _background(
    Map<String, String> story,
  ) {
    final type =
        (story['backgroundType'] ?? '').isNotEmpty
            ? story['backgroundType']!
            : story['type'] ?? 'text';

    final path =
        (story['backgroundPath'] ?? '').isNotEmpty
            ? story['backgroundPath']!
            : story['path'] ?? '';

    if (type == 'video' && File(path).existsSync()) {
      if (_video?.value.isInitialized == true) {
        final size = _video!.value.size;

        return FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: size.width,
            height: size.height,
            child: VideoPlayer(_video!),
          ),
        );
      }

      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (type == 'image' && File(path).existsSync()) {
      return Image.file(
        File(path),
        fit: BoxFit.cover,
        width: double.infinity,
        height: double.infinity,
        filterQuality: FilterQuality.high,
      );
    }

    return Container(
      color: const Color(0xFF181614),
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(
        horizontal: 28,
      ),
      child: Text(
        story['text'] ?? '',
        textAlign: TextAlign.center,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 29,
          height: 1.2,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
