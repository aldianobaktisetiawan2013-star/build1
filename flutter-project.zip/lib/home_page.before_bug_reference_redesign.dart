// COMIC_MATTE_UI_PASS: all screens inherit the shared 3D Comic Matte component system.
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'main.dart';

const _baseUrl = 'http://kontolilegalzyro.rexypediaa.biz.id:3055';

bool _canGlobal(String r) {
  final l = r.toLowerCase();
  return l == 'high owner' || l == 'owner' || l == 'high admin' || l == 'vip';
}

class HomePage extends StatefulWidget {
  final String username, password, sessionKey, role, expiredDate;
  final List<Map<String, dynamic>> listBug;
  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl    = TextEditingController();
  final _bugScrollCtrl = ScrollController();
  String  _selectedBugId = '';
  String  _bugMode    = 'number';
  String  _senderType = 'private';
  bool    _isSending  = false;
  String? _responseMsg;
  List<String> _globalSenders = [];
  bool _loadingSenders = false;

  late AnimationController _auroraCtrl, _entranceCtrl, _btnCtrl, _resultCtrl, _pulseCtrl, _glowCtrl;
  late Animation<double> _fade, _btnGlow, _resultFade, _pulse, _glow;
  late Animation<Offset>  _resultSlide;

  VideoPlayerController? _vCtrl;
  ChewieController?      _chewieCtrl;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    if (widget.listBug.isNotEmpty) _selectedBugId = widget.listBug[0]['bug_id'] ?? '';

    _auroraCtrl   = AnimationController(vsync: this, duration: const Duration(seconds: 18))..repeat();
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _btnCtrl      = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
    _resultCtrl   = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _pulseCtrl    = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _glowCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);

    _fade        = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _btnGlow     = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _btnCtrl, curve: Curves.easeInOut));
    _resultFade  = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));
    _pulse       = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _glow        = Tween<double>(begin: 0.3, end: 1.0).animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _initVideo();
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _auroraCtrl.dispose(); _entranceCtrl.dispose(); _btnCtrl.dispose();
    _resultCtrl.dispose(); _pulseCtrl.dispose(); _glowCtrl.dispose();
    _targetCtrl.dispose(); _bugScrollCtrl.dispose();
    _vCtrl?.dispose(); _chewieCtrl?.dispose();
    super.dispose();
  }

  void _initVideo() {
    _vCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {
          _chewieCtrl = ChewieController(
            videoPlayerController: _vCtrl!,
            autoPlay: true, looping: true, showControls: false,
          );
          _videoReady = true;
        });
      });
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _loadingSenders = true);
    try {
      final r = await http.get(Uri.parse(
          '$_baseUrl/getActiveSenders?key=${widget.sessionKey}'
      )).timeout(const Duration(seconds: 10));
      final d = jsonDecode(r.body);
      if (d['valid'] == true && d['senders'] != null && mounted)
        setState(() => _globalSenders = List<String>.from(d['senders']));
    } catch (_) {}
    finally { if (mounted) setState(() => _loadingSenders = false); }
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_bugMode == 'number' && _formatPhone(raw) == null) {
      _showAlert('Nomor Tidak Valid', 'Gunakan format: +62812xxxxxxxx'); return;
    }
    if (_bugMode == 'group' && !_validGroup(raw)) {
      _showAlert('Link Tidak Valid', 'Masukkan link grup WA yang valid.\nhttps://chat.whatsapp.com/XXX'); return;
    }
    if (_senderType == 'global' && !_canGlobal(widget.role)) {
      _showAlert('Akses Ditolak', 'Sender Global hanya untuk High Owner, Owner, High Admin & VIP!'); return;
    }
    if (_selectedBugId.isEmpty) { _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.'); return; }

    setState(() => _isSending = true);
    _resultCtrl.reset();
    HapticFeedback.mediumImpact();

    try {
      final enc = Uri.encodeComponent(raw);
      final url = Uri.parse('$_baseUrl/sendBug?key=${widget.sessionKey}&target=$enc&bug=$_selectedBugId'
          '${_senderType == "global" ? "&senderMode=global" : ""}');
      final res  = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == false)         _setResp('error',   'Session tidak valid. Login ulang.');
      else if (data['cooldown'] == true)  _setResp('warning', 'Cooldown aktif! Tunggu ${data['wait'] ?? 0}s lagi.');
      else if (data['sended'] == true)  {
        HapticFeedback.lightImpact();
        final target = _bugMode == 'group' ? 'grup target' : raw;
        _targetCtrl.clear();
        setState(() => _responseMsg = null);
        if (mounted) _showSuccessDialog(target);
      }
      else                                _setResp('error',   'Gagal kirim. Server maintenance.');
    } catch (e) {
      _setResp('error', e.toString().contains('Timeout') ? 'Request timeout!' : 'Koneksi error!');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _setResp(String t, String m) {
    if (!mounted) return;
    setState(() => _responseMsg = '$t|$m');
    _resultCtrl.forward(from: 0);
  }

  String? _formatPhone(String s) {
    final c = s.replaceAll(RegExp(r'[^\d+]'), '');
    return (c.startsWith('+') && c.length >= 8) ? c : null;
  }
  bool _validGroup(String s) => s.startsWith('https://') && s.contains('chat.whatsapp.com');

  void _showSuccessDialog(String target) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.75),
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, a, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: a, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0D1120),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.success.withOpacity(0.35), width: 1.5),
            boxShadow: [
              BoxShadow(color: AppColors.success.withOpacity(0.15), blurRadius: 0, spreadRadius: 4),
            ],
          ),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 22),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            // ── Ikon centang hijau ────────────────────────────────
            Container(
              width: 60, height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.success,
                boxShadow: [
                  BoxShadow(color: AppColors.success.withOpacity(0.5), blurRadius: 0, spreadRadius: 2),
                ],
              ),
              child: const Icon(Icons.check_rounded, color: Colors.white, size: 30),
            ),
            const SizedBox(height: 16),
            // ── Judul ─────────────────────────────────────────────
            const Text('Bug Terkirim', style: TextStyle(
              fontFamily: 'Orbitron', fontSize: 18,
              fontWeight: FontWeight.w900, color: AppColors.textPrimary,
              letterSpacing: 0.5,
            )),
            const SizedBox(height: 6),
            const Text('Bug berhasil dikirim ke target:', style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 12,
              color: AppColors.textSub,
            )),
            const SizedBox(height: 12),
            // ── Nomor target ──────────────────────────────────────
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: AppColors.surface.withOpacity(0.6),
                border: Border.all(color: AppColors.borderGlow),
              ),
              child: Row(children: [
                const Icon(Icons.smartphone_rounded, color: AppColors.textSub, size: 18),
                const SizedBox(width: 12),
                Text(target, style: const TextStyle(
                  fontFamily: 'ShareTechMono', fontSize: 14,
                  color: AppColors.textPrimary, fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                )),
              ]),
            ),
            const SizedBox(height: 16),
            // ── Tombol SELESAI ────────────────────────────────────
            GestureDetector(
              onTap: () => Navigator.pop(ctx),
              child: Container(
                width: double.infinity, height: 46,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6F8A72), Color(0xFF63856D)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(color: AppColors.success.withOpacity(0.4), blurRadius: 0, offset: const Offset(0, 6)),
                  ],
                ),
                child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text('SELESAI', style: TextStyle(
                    fontFamily: 'Orbitron', fontSize: 12, fontWeight: FontWeight.w900,
                    color: Colors.white, letterSpacing: 2,
                  )),
                  SizedBox(width: 8),
                  Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            // ── Copyright ─────────────────────────────────────────
            const Text('© Xeon Project', style: TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 9,
              color: AppColors.textMuted, letterSpacing: 1,
            )),
          ]),
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showGeneralDialog(
      context: context, barrierDismissible: true, barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 280),
      transitionBuilder: (_, a, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: a, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: a, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.warning.withOpacity(0.3), width: 1.5),
            boxShadow: [BoxShadow(color: AppColors.warning.withOpacity(0.1), blurRadius: 0)],
          ),
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 56, height: 56,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: AppColors.warning.withOpacity(0.12),
                border: Border.all(color: AppColors.warning.withOpacity(0.4))),
              child: const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 26)),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontFamily: 'Orbitron', fontSize: 15,
              fontWeight: FontWeight.w800, color: AppColors.textPrimary)),
            const SizedBox(height: 9),
            Text(msg, textAlign: TextAlign.center, style: const TextStyle(
              fontFamily: 'ShareTechMono', fontSize: 13, color: AppColors.textSub, height: 1.5)),
            const SizedBox(height: 22),
            _ActionBtn(label: 'OK', colors: const [AppColors.warning, Color(0xFFE65100)],
              onTap: () => Navigator.pop(ctx), fullWidth: true),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.bg,
    body: SafeArea(
      child: FadeTransition(
        opacity: _fade,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 38),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            _buildHeader(),
            const SizedBox(height: 18),
            _buildVideoCard(),
            const SizedBox(height: 20),
            _ComicSection(title: 'PILIH TARGET', icon: Icons.tune_rounded, child: _buildModeToggle()),
            const SizedBox(height: 14),
            _buildTargetInput(),
            const SizedBox(height: 20),
            _buildBugSelector(),
            const SizedBox(height: 20),
            _buildSenderCard(),
            if (_senderType == 'global' && _canGlobal(widget.role)) ...[
              const SizedBox(height: 12),
              _buildGlobalSenderList(),
            ],
            const SizedBox(height: 24),
            _buildSendButton(),
            if (_responseMsg != null) ...[
              const SizedBox(height: 12),
              _buildResultBanner(),
            ],
          ]),
        ),
      ),
    ),
  );

  Widget _buildHeader() => _ComicPanel(
    padding: const EdgeInsets.all(16),
    accent: AppColors.cyan,
    child: Row(children: [
      _ComicIcon(icon: Icons.bug_report_rounded, color: AppColors.cyan),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.username.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
        const SizedBox(height: 6),
        Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
          _ComicBadge(label: widget.role.toUpperCase(), color: AppColors.success),
          Text('AKTIF • ${widget.expiredDate}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textSub)),
        ]),
      ])),
      const SizedBox(width: 10),
      _ComicIcon(icon: Icons.flash_on_rounded, color: AppColors.warning, small: true),
    ]),
  );

  Widget _buildVideoCard() => _ComicPanel(
    padding: const EdgeInsets.all(8),
    accent: AppColors.violet,
    child: ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: SizedBox(height: 188,
        child: _videoReady && _chewieCtrl != null
          ? Chewie(controller: _chewieCtrl!)
          : const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              CircularProgressIndicator(strokeWidth: 3, color: AppColors.cyan),
              SizedBox(height: 12),
              Text('MEMUAT BANNER', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: AppColors.textSub)),
            ])),
      ),
    ),
  );

  Widget _buildModeToggle() => Row(children: [
    Expanded(child: _ComicChoice(label: 'NOMOR', icon: Icons.smartphone_rounded, active: _bugMode == 'number', onTap: () => setState(() => _bugMode = 'number'))),
    const SizedBox(width: 10),
    Expanded(child: _ComicChoice(label: 'GRUP', icon: Icons.groups_rounded, active: _bugMode == 'group', onTap: () => setState(() => _bugMode = 'group'))),
  ]);

  Widget _buildTargetInput() => _ComicSection(
    title: _bugMode == 'number' ? 'TARGET NOMOR' : 'TARGET GRUP',
    icon: _bugMode == 'number' ? Icons.phone_android_rounded : Icons.group_rounded,
    child: _ComicPanel(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      accent: AppColors.cyan,
      child: TextField(
        controller: _targetCtrl,
        onChanged: (_) => setState(() {}),
        keyboardType: _bugMode == 'number' ? TextInputType.phone : TextInputType.url,
        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: _bugMode == 'number' ? '+62812xxxxxxxx' : 'https://chat.whatsapp.com/...',
          hintStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textMuted),
          prefixIcon: Icon(_bugMode == 'number' ? Icons.smartphone_rounded : Icons.link_rounded, color: AppColors.cyan),
          suffixIcon: _targetCtrl.text.isNotEmpty ? IconButton(icon: const Icon(Icons.close_rounded), color: AppColors.textMuted, onPressed: () => setState(_targetCtrl.clear)) : null,
        ),
      ),
    ),
  );

  Widget _buildBugSelector() => _ComicSection(
    title: 'PILIH BUG', icon: Icons.widgets_rounded,
    trailing: Text('${widget.listBug.length} tersedia', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
    child: SizedBox(height: 112, child: ListView.separated(
      controller: _bugScrollCtrl,
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      itemCount: widget.listBug.length,
      separatorBuilder: (_, __) => const SizedBox(width: 10),
      itemBuilder: (_, i) {
        final b = widget.listBug[i];
        final id = b['bug_id'] ?? '';
        final name = b['bug_name'] ?? 'Bug ${i + 1}';
        final active = id == _selectedBugId;
        return GestureDetector(
          onTap: () => setState(() => _selectedBugId = id),
          child: AnimatedScale(duration: const Duration(milliseconds: 180), scale: active ? 1 : .96,
            child: SizedBox(width: 160, child: _ComicPanel(
              accent: active ? AppColors.danger : AppColors.borderActive,
              padding: const EdgeInsets.all(14),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                _ComicIcon(icon: Icons.extension_rounded, color: active ? AppColors.danger : AppColors.cyan, small: true),
                const SizedBox(height: 9),
                Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: active ? AppColors.textPrimary : AppColors.textSub)),
              ]),
            )),
          ),
        );
      },
    )),
  );

  Widget _buildSenderCard() {
    final canGlobal = _canGlobal(widget.role);
    return _ComicSection(
      title: 'MODE SENDER', icon: Icons.send_rounded,
      child: Row(children: [
        Expanded(child: GestureDetector(onTap: () => setState(() => _senderType = 'private'), child: _ComicModeCard(label: 'PRIVATE', sub: 'Sender pribadi', icon: Icons.person_rounded, active: _senderType == 'private', color: AppColors.cyan))),
        const SizedBox(width: 10),
        Expanded(child: Opacity(
          opacity: canGlobal ? 1 : .5,
          child: GestureDetector(onTap: () { if (!canGlobal) { _showAlert('Akses Ditolak', 'Role kamu belum memiliki akses sender global.'); return; } setState(() => _senderType = 'global'); if (_globalSenders.isEmpty) _loadGlobalSenders(); }, child: _ComicModeCard(label: 'GLOBAL', sub: _loadingSenders ? 'Memuat...' : '${_globalSenders.length} sender aktif', icon: Icons.public_rounded, active: _senderType == 'global', color: AppColors.violet)),
        )),
      ]),
    );
  }

  Widget _buildGlobalSenderList() => _ComicPanel(
    accent: AppColors.violet,
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Icon(Icons.people_alt_rounded, color: AppColors.violet, size: 19),
        const SizedBox(width: 8),
        const Expanded(child: Text('SENDER GLOBAL AKTIF', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.textPrimary))),
        IconButton(onPressed: _loadGlobalSenders, icon: const Icon(Icons.refresh_rounded), color: AppColors.violet),
      ]),
      const SizedBox(height: 10),
      if (_loadingSenders) const Center(child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(color: AppColors.violet)))
      else if (_globalSenders.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('Belum ada sender global aktif.', style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.textMuted)))
      else _buildSenderListCompact(),
    ]),
  );

  Widget _buildSenderListCompact() {
    final first = _globalSenders.first;
    final more = _globalSenders.length - 1;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 18), const SizedBox(width: 8), Expanded(child: Text(first, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.textPrimary)))]),
      if (more > 0) Padding(padding: const EdgeInsets.only(top: 8), child: TextButton(onPressed: _showAllSenders, child: Text('Lihat $more sender lainnya'))),
    ]);
  }

  void _showAllSenders() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _ComicPanel(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 30),
        accent: AppColors.violet,
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('SEMUA SENDER GLOBAL', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
              const SizedBox(height: 14),
              ..._globalSenders.asMap().entries.map(
                (e) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _ComicPanel(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    accent: AppColors.success,
                    child: Row(children: [
                      const Icon(Icons.check_circle_rounded, color: AppColors.success, size: 18),
                      const SizedBox(width: 10),
                      Expanded(child: Text(e.value, style: const TextStyle(fontWeight: FontWeight.w700))),
                      Text('#${e.key + 1}', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.textMuted)),
                    ]),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSendButton() => GestureDetector(
    onTap: _isSending ? null : _sendBug,
    child: AnimatedScale(duration: const Duration(milliseconds: 140), scale: _isSending ? .98 : 1,
      child: _ComicPanel(
        accent: _isSending ? AppColors.borderActive : AppColors.danger,
        fill: _isSending ? AppColors.surfaceAlt : const Color(0xFFFDEBE9),
        padding: EdgeInsets.zero,
        child: SizedBox(height: 62, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: _isSending
          ? const [SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 3, color: AppColors.danger)), SizedBox(width: 12), Text('MEMPROSES...', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.textPrimary))]
          : const [Icon(Icons.send_rounded, color: AppColors.danger), SizedBox(width: 10), Text('KIRIM SEKARANG', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: AppColors.textPrimary))],
        )),
      ),
    ),
  );

  Widget _buildResultBanner() {
    final parts = _responseMsg!.split('|');
    final type = parts.first;
    final msg = parts.length > 1 ? parts[1] : '';
    final color = type == 'success' ? AppColors.success : type == 'warning' ? AppColors.warning : AppColors.danger;
    return FadeTransition(opacity: _resultFade, child: _ComicPanel(accent: color, fill: color.withOpacity(.08), padding: const EdgeInsets.all(15), child: Row(children: [Icon(type == 'warning' ? Icons.warning_rounded : Icons.info_rounded, color: color), const SizedBox(width: 10), Expanded(child: Text(msg, style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.textPrimary)))])));
  }
}

// ── Reusable Comic 3D UI ─────────────────────────────────────
class _ActionBtn extends StatelessWidget {
  final String label;
  final List<Color> colors;
  final VoidCallback? onTap;
  final bool fullWidth;

  const _ActionBtn({
    required this.label,
    required this.colors,
    required this.onTap,
    this.fullWidth = false,
  });

  @override
  Widget build(BuildContext context) {
    final background = colors.isNotEmpty ? colors.first : AppColors.primary;
    final child = Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Ink(
          height: 52,
          decoration: BoxDecoration(
            color: background,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.primaryDark.withOpacity(.45)),
            boxShadow: const [
              BoxShadow(color: Color(0x1F000000), offset: Offset(0, 4), blurRadius: 0),
            ],
          ),
          child: Center(
            child: Text(
              label,
              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w900),
            ),
          ),
        ),
      ),
    );
    return fullWidth ? SizedBox(width: double.infinity, child: child) : child;
  }
}

class _ComicPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color accent;
  final Color? fill;
  const _ComicPanel({required this.child, required this.accent, this.fill, this.padding = const EdgeInsets.all(14)});
  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: accent.withOpacity(.30),
      borderRadius: BorderRadius.circular(22),
    ),
    padding: const EdgeInsets.only(bottom: 6),
    child: Container(
      padding: padding,
      decoration: BoxDecoration(
        color: fill ?? AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.borderActive, width: 1.2),
      ),
      child: child,
    ),
  );
}

class _ComicSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;
  final Widget? trailing;
  const _ComicSection({required this.title, required this.icon, required this.child, this.trailing});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Padding(padding: const EdgeInsets.only(left: 4, bottom: 9), child: Row(children: [Icon(icon, size: 18, color: AppColors.cyan), const SizedBox(width: 8), Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: AppColors.textPrimary)), const Spacer(), if (trailing != null) trailing!])),
    child,
  ]);
}

class _ComicIcon extends StatelessWidget {
  final IconData icon; final Color color; final bool small;
  const _ComicIcon({required this.icon, required this.color, this.small = false});
  @override
  Widget build(BuildContext context) { final s = small ? 42.0 : 58.0; return Container(width: s, height: s, decoration: BoxDecoration(color: color.withOpacity(.16), borderRadius: BorderRadius.circular(small ? 14 : 20), border: Border.all(color: color.withOpacity(.55), width: 1.2)), child: Icon(icon, color: color, size: small ? 22 : 30)); }
}

class _ComicBadge extends StatelessWidget {
  final String label; final Color color;
  const _ComicBadge({required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(.45))), child: Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: color)));
}

class _ComicChoice extends StatelessWidget {
  final String label; final IconData icon; final bool active; final VoidCallback onTap;
  const _ComicChoice({required this.label, required this.icon, required this.active, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(onTap: onTap, child: _ComicPanel(accent: active ? AppColors.cyan : AppColors.borderActive, fill: active ? AppColors.cyan.withOpacity(.10) : AppColors.surface, padding: const EdgeInsets.symmetric(vertical: 14), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: active ? AppColors.cyan : AppColors.textMuted), const SizedBox(width: 8), Text(label, style: TextStyle(fontWeight: FontWeight.w900, color: active ? AppColors.cyanDark : AppColors.textSub))])));
}

class _ComicModeCard extends StatelessWidget {
  final String label, sub; final IconData icon; final bool active; final Color color;
  const _ComicModeCard({required this.label, required this.sub, required this.icon, required this.active, required this.color});
  @override
  Widget build(BuildContext context) => _ComicPanel(accent: active ? color : AppColors.borderActive, fill: active ? color.withOpacity(.08) : AppColors.surface, padding: const EdgeInsets.all(14), child: Column(children: [Icon(icon, color: active ? color : AppColors.textMuted), const SizedBox(height: 7), Text(label, style: TextStyle(fontWeight: FontWeight.w900, color: active ? color : AppColors.textPrimary)), const SizedBox(height: 3), Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textMuted))]));
}
