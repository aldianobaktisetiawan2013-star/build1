// COMIC_MATTE_UI_PASS: all screens inherit the shared 3D Comic Matte component system.
// lib/thanksto.dart
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'main.dart';
import 'design_system/comic_page.dart';

// ============================
// CONFIG DATA
// ============================

final List<Map<String, String>> thanksToList = [
  {
    "name": "𝑲𝒓𝒊𝒛 || 𝐄𝐬 𝐤𝐫𝐢𝐦",
    "role": "Developer",
    "photo": "https://ibb.co/mVLT6Xms",
    "telegram": "@krizoficialll",
  },
  {
    "name": "𝐑𝐚𝐦𝐣𝐢 || 𝐄𝐬 𝐤𝐫𝐢𝐦",
    "role": "My Friend",
    "photo": "https://ibb.co/N2mGtbM4",
    "telegram": "@xRamji",
  },
  {
    "name": "〈 ⸸𝚡𝚟𝚊̀𝚗𝚎̈𝚜𝚌𝚝 || 𝚁𝚊𝚙𝚙 卐〉",
    "role": "Dev sc",
    "photo": "https://ibb.co/wFWJc9NF",
    "telegram": "@PanzKecebaday",
  }, 
];

class ThanksToPage extends StatefulWidget {
  final String? role;
  final dynamic expiredDate;

  const ThanksToPage({
    super.key,
    this.role,
    this.expiredDate,
  });

  @override
  State<ThanksToPage> createState() => _ThanksToPageState();
}

class _ThanksToPageState extends State<ThanksToPage> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ComicScaffold(
      backgroundColor: AppColors.bg,
      appBar: _buildPremiumAppBar(),
      body: _buildPremiumBackground(),
    );
  }

  PreferredSizeWidget _buildPremiumAppBar() {
    return AppBar(
      backgroundColor: AppColors.surface,
      elevation: 0,
      centerTitle: true,
      leading: GestureDetector(
        onTap: () => Navigator.pop(context),
        child: Container(
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.surfaceAlt,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.border, width: 1),
          ),
          child: const Center(
            child: Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.textPrimary, size: 20),
          ),
        ),
      ),
      title: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.surfaceAlt,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.border, width: 1),
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.star_rounded, color: Colors.amber, size: 20),
            SizedBox(width: 8),
            Text(
              "Thanks To",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
                fontSize: 18,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
      actions: [
        Container(
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.surfaceAlt,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.border, width: 1),
          ),
          child: const Center(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: Icon(Icons.auto_awesome_rounded, color: AppColors.textPrimary, size: 20),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPremiumBackground() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.bg,
            AppColors.surface,
            AppColors.surfaceAlt,
            AppColors.card,
          ],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            _buildHeaderCard(),
            const SizedBox(height: 24),
            _buildListView(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.card, AppColors.surfaceAlt],
        ),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppColors.border, width: 1),
        boxShadow: [
          BoxShadow(
            color: AppColors.borderActive.withOpacity(0.18),
            blurRadius: 0,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [AppColors.cyanDim, AppColors.cyan]),
              borderRadius: BorderRadius.all(Radius.circular(20)),
            ),
            child: const Icon(Icons.people_alt_rounded, color: AppColors.textPrimary, size: 30),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Special Appreciation",
                  style: TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w500),
                ),
                SizedBox(height: 4),
                Text(
                  "Tap Name To chat on Telegram",
                  style: TextStyle(color: AppColors.textSub, fontSize: 11),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.surfaceAlt,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Text(
              "${thanksToList.length} Members",
              style: const TextStyle(color: AppColors.textPrimary, fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildListView() {
    return Expanded(
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: thanksToList.length,
        itemBuilder: (context, index) {
          final person = thanksToList[index];
          return FadeTransition(
            opacity: _animationController.drive(
              Tween<double>(begin: 0, end: 1).chain(CurveTween(curve: Curves.easeOut)),
            ),
            child: SlideTransition(
              position: _animationController.drive(
                Tween<Offset>(begin: const Offset(0, 0.5), end: Offset.zero)
                    .chain(CurveTween(curve: Curves.easeOutCubic)),
              ),
              child: Container(
                margin: const EdgeInsets.only(bottom: 16),
                child: _buildPremiumCard(
                  name: person['name']!,
                  role: person['role']!,
                  photo: person['photo']!,
                  telegram: person['telegram']!,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildPremiumCard({
    required String name,
    required String role,
    required String photo,
    required String telegram,
  }) {
    return GestureDetector(
      onTap: () => _openTelegram(telegram),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.white.withOpacity(0.1), AppColors.surfaceAlt],
          ),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(color: AppColors.border, width: 1),
          boxShadow: [
            BoxShadow(
              color: AppColors.borderActive.withOpacity(0.14),
              blurRadius: 0,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _openTelegram(telegram),
            borderRadius: BorderRadius.circular(25),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Avatar
                  Container(
                    width: 65,
                    height: 65,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [AppColors.cyanDim, AppColors.cyan],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.cyanDim.withOpacity(0.3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(2),
                      child: ClipOval(
                        child: Image.network(
                          photo,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              color: Colors.grey.shade800,
                              child: const Icon(Icons.person_rounded, size: 35, color: AppColors.textMuted),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  // Name and Role
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                name,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textPrimary,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 5),
                            // Centang biru rapi tanpa text
                            const Icon(
                              Icons.verified_rounded,
                              color: AppColors.cyanDim,
                              size: 16,
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                AppColors.cyanDim.withOpacity(0.2),
                                AppColors.cyan.withOpacity(0.1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: AppColors.cyanDim.withOpacity(0.3), width: 0.5),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.star_rounded, color: AppColors.cyanDim, size: 12),
                              const SizedBox(width: 4),
                              Text(
                                role,
                                style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.cyanDim.withOpacity(0.9),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Telegram Icon
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [AppColors.cyanDim, AppColors.cyan]),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.cyanDim.withOpacity(0.3),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Icon(Icons.telegram, color: AppColors.textPrimary, size: 24),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // TELEGRAM OPENER - FIX TOTAL 100% WORKING
  Future<void> _openTelegram(String username) async {
    String cleanUsername = username.replaceAll('@', '').trim();

    if (cleanUsername.isEmpty) {
      _showErrorSnackbar('Username Telegram kosong');
      return;
    }

    // Method 1: Buka app Telegram langsung via tg:// scheme
    try {
      final tgUrl = Uri.parse('tg://resolve?domain=$cleanUsername');
      final launched = await launchUrl(tgUrl, mode: LaunchMode.externalApplication);
      if (launched) return;
    } catch (_) {}

    // Method 2: Buka via https://t.me/ (fallback browser/app)
    try {
      final tmeUrl = Uri.parse('https://t.me/$cleanUsername');
      final launched = await launchUrl(tmeUrl, mode: LaunchMode.externalApplication);
      if (launched) return;
    } catch (_) {}

    // Method 3: Fallback telegram.me
    try {
      final telegramMeUrl = Uri.parse('https://telegram.me/$cleanUsername');
      await launchUrl(telegramMeUrl, mode: LaunchMode.externalApplication);
      return;
    } catch (_) {}

    // Semua gagal
    _showErrorSnackbar('Gagal membuka @$cleanUsername');
  }

  void _showErrorSnackbar(String message) {
    if (!mounted) return;
    
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error_outline, color: AppColors.textPrimary, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(fontSize: 14),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.red.shade900,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
    );
  }
}