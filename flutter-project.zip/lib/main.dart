// COMIC_MATTE_UI_PASS: all screens inherit the shared 3D Comic Matte component system.
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'design_system/comic_shell.dart';

// ═══════════════════════════════════════════════════════════════
//  PROFESSIONAL 3D COMIC — MUTED PASTEL COLOR SYSTEM
//  Soft • Premium • Harmonious • One accent per card
// ═══════════════════════════════════════════════════════════════
class AppColors {
  // Canvas — cream kertas komik TEBAL, tidak pucat/transparan
  static const bg           = Color(0xFFF0E6D2);
  static const bgDeep       = Color(0xFFE5D6B8);
  static const surface      = Color(0xFFF8F0E0);
  static const surfaceAlt   = Color(0xFFEDE2C8);
  static const card         = Color(0xFFFFFBF3);
  static const cardHover    = Color(0xFFF5EBD6);

  // Outline charcoal tegas
  static const border       = Color(0xFF2E2A26);
  static const borderGlow   = Color(0xFF1F1C19);
  static const borderActive = Color(0xFF181614);

  // ── Aksen jelas (satu warna solid per card) ──
  static const dustyBlue    = Color(0xFF3D6B8C);
  static const dustyBlueDim = Color(0xFF2F5570);
  static const sageGreen    = Color(0xFF4A7A55);
  static const sageGreenDim = Color(0xFF3A6244);
  static const softLavender = Color(0xFF6B5A9A);
  static const softLavenderDim = Color(0xFF56487C);
  static const mutedCoral   = Color(0xFFC45A48);
  static const mutedCoralDim= Color(0xFFA3483A);
  static const softMustard  = Color(0xFFC4922A);
  static const softMustardDim = Color(0xFFA67A20);
  static const terracotta   = Color(0xFFB05A3A);
  static const terracottaDim= Color(0xFF8F4830);
  static const dustyCyan    = Color(0xFF3A8A8A);
  static const dustyCyanDim = Color(0xFF2E7070);
  static const mutedPeach   = Color(0xFFD4845C);
  static const mutedPeachDim= Color(0xFFB06C48);
  static const softViolet   = Color(0xFF5A4A8A);
  static const softVioletDim= Color(0xFF483C70);
  static const warmAmber    = Color(0xFFC47A20);
  static const warmAmberDim = Color(0xFFA46418);

  // Semantic — jelas
  static const success      = Color(0xFF3D8A52);
  static const successDim   = Color(0xFF2F6E40);
  static const warning      = Color(0xFFC4922A);
  static const danger       = Color(0xFFC04545);
  static const dangerDim    = Color(0xFF9A3535);

  // Legacy aliases (keep existing screens compiling)
  static const cyan         = dustyBlue;
  static const cyanDim      = dustyBlueDim;
  static const cyanDark     = Color(0xFF3D5A70);
  static const violet       = softViolet;
  static const violetBright = softLavender;
  static const violetGlow   = Color(0xFFE8E2F0);
  static const electric     = warmAmber;
  static const azure        = dustyCyan;
  static const indigo       = Color(0xFF5A6570);
  static const gold         = softMustard;
  static const goldDim      = softMustardDim;
  static const comicOrange  = terracotta;
  static const comicOrangeDark = terracottaDim;
  static const headerRed    = mutedCoral;

  // Text
  static const textPrimary  = Color(0xFF1F1C19);
  static const textSub      = Color(0xFF4F4A44);
  static const textMuted    = Color(0xFF7A746C);
  static const textDim      = Color(0xFFA39B91);

  static const primary      = dustyBlue;
  static const primaryDark  = dustyBlueDim;
  static const secondary    = sageGreen;

  // Soft single-hue gradients only (no rainbow)
  static const LinearGradient heroGrad = LinearGradient(
    colors: [Color(0xFFFFFEFB), Color(0xFFF5F2EC)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
  static const LinearGradient cyanGrad = LinearGradient(
    colors: [Color(0xFF5B7C99), Color(0xFF4A6880)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient violetGrad = LinearGradient(
    colors: [Color(0xFF8B7BA8), Color(0xFF756692)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient glowGrad = LinearGradient(
    colors: [Color(0xFFFFFEFB), Color(0xFFF0EBE3)],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );
  static const LinearGradient cardGrad = LinearGradient(
    colors: [Color(0xFFFFFEFB), Color(0xFFFAF8F4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  /// Ordered accent list for menu cards (use index % length)
  static const List<Color> menuAccents = [
    dustyBlue,
    sageGreen,
    softLavender,
    mutedCoral,
    softMustard,
    terracotta,
    dustyCyan,
    mutedPeach,
    softViolet,
    warmAmber,
  ];
}

// ═══════════════════════════════════════════════════════════════
//  PREMIUM THEME
// ═══════════════════════════════════════════════════════════════
class AppTheme {
  static const _fontMono    = 'ShareTechMono';
  static const _fontDisplay = 'Orbitron';

  static ThemeData build() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    fontFamily: null,
    scaffoldBackgroundColor: AppColors.bg,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    splashColor: AppColors.cyan.withOpacity(.10),
    highlightColor: Colors.transparent,

    colorScheme: const ColorScheme.light(
      brightness:              Brightness.light,
      primary:                 AppColors.dustyBlue,
      onPrimary:               Colors.white,
      primaryContainer:        AppColors.dustyBlueDim,
      onPrimaryContainer:      Colors.white,
      secondary:               AppColors.sageGreen,
      onSecondary:             Colors.white,
      secondaryContainer:      AppColors.sageGreenDim,
      onSecondaryContainer:    Colors.white,
      tertiary:                AppColors.softLavender,
      onTertiary:              Colors.white,
      error:                   AppColors.danger,
      onError:                 Colors.white,
      surface:                 AppColors.surface,
      onSurface:               AppColors.textPrimary,
      surfaceContainerHighest: AppColors.card,
      outline:                 AppColors.borderActive,
      outlineVariant:          AppColors.border,
      shadow:                  Color(0x401A1816),
      scrim:                   Color(0x66000000),
      inverseSurface:          AppColors.textPrimary,
      onInverseSurface:        AppColors.bg,
      inversePrimary:          AppColors.dustyBlueDim,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor:        AppColors.surface,
      foregroundColor:        AppColors.textPrimary,
      elevation:              0,
      scrolledUnderElevation: 0,
      centerTitle:            false,
      titleTextStyle: TextStyle(
        fontSize:      18,
        fontWeight:    FontWeight.w900,
        color:         AppColors.textPrimary,
        letterSpacing: 0.2,
      ),
      iconTheme:        IconThemeData(color: AppColors.textPrimary, size: 22),
      actionsIconTheme: IconThemeData(color: AppColors.textSub,  size: 20),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor:                    Colors.transparent,
        statusBarIconBrightness:           Brightness.dark,
        statusBarBrightness:               Brightness.dark,
        systemNavigationBarColor:          AppColors.bg,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    ),

    cardTheme: CardThemeData(
      color:        AppColors.card,
      elevation:    0,
      shadowColor: AppColors.borderActive,
      margin:       EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.borderActive, width: 2.2),
      ),
      clipBehavior: Clip.antiAlias,
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return AppColors.border;
          if (s.contains(WidgetState.pressed))  return AppColors.dustyBlueDim;
          return AppColors.dustyBlue;
        }),
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return AppColors.textMuted;
          return Colors.white;
        }),
        overlayColor:  WidgetStateProperty.all(Colors.transparent),
        elevation:     WidgetStateProperty.all(0),
        shadowColor:   WidgetStateProperty.all(Colors.transparent),
        padding:       WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: AppColors.borderActive, width: 2.2),
          ),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: null, fontSize: 14, fontWeight: FontWeight.w900, letterSpacing: 0.2),
        ),
        animationDuration: const Duration(milliseconds: 120),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return AppColors.textPrimary;
          return AppColors.textPrimary;
        }),
        side: WidgetStateProperty.resolveWith((s) {
          return const BorderSide(color: AppColors.borderActive, width: 2.2);
        }),
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return AppColors.surfaceAlt;
          return AppColors.card;
        }),
        overlayColor: WidgetStateProperty.all(AppColors.gold.withOpacity(0.12)),
        padding: WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: null, fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 0.1),
        ),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return AppColors.textPrimary;
          return AppColors.cyanDim;
        }),
        overlayColor: WidgetStateProperty.all(AppColors.gold.withOpacity(0.12)),
        padding: WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _fontMono, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 0.3),
        ),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled:      true,
      fillColor:   AppColors.card,
      hoverColor:  AppColors.surfaceAlt,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.borderActive, width: 2.2),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.borderActive, width: 2.2),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.dustyBlue, width: 2.4),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.danger, width: 2.2),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.danger, width: 2.6),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.textDim, width: 1.6),
      ),
      labelStyle:         const TextStyle(color: AppColors.textSub,  fontSize: 13, fontWeight: FontWeight.w700),
      hintStyle:          const TextStyle(color: AppColors.textMuted, fontSize: 13),
      errorStyle:         const TextStyle(color: AppColors.danger,    fontSize: 11),
      prefixIconColor:    AppColors.textSub,
      suffixIconColor:    AppColors.textSub,
      floatingLabelStyle: const TextStyle(color: AppColors.dustyBlue, fontSize: 12, fontWeight: FontWeight.w800),
    ),

    chipTheme: ChipThemeData(
      backgroundColor:     AppColors.dustyBlue.withOpacity(0.14),
      selectedColor:       AppColors.dustyBlue.withOpacity(0.28),
      disabledColor:       AppColors.border,
      deleteIconColor:     AppColors.textSub,
      labelStyle:          const TextStyle(color: AppColors.textPrimary, fontSize: 12, fontWeight: FontWeight.w800),
      secondaryLabelStyle: const TextStyle(color: AppColors.textPrimary, fontSize: 12, fontWeight: FontWeight.w800),
      padding:             const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.borderActive, width: 1.8),
      ),
      side:           const BorderSide(color: AppColors.borderActive, width: 1.8),
      elevation:      0,
      pressElevation: 0,
      showCheckmark:  false,
    ),

    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor:      AppColors.surface,
      selectedItemColor:    AppColors.dustyBlue,
      unselectedItemColor:  AppColors.textMuted,
      elevation:            0,
      type:                 BottomNavigationBarType.fixed,
      selectedLabelStyle:   TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
      unselectedLabelStyle: TextStyle(fontSize: 10, fontWeight: FontWeight.w600),
    ),

    navigationBarTheme: NavigationBarThemeData(
      backgroundColor:  AppColors.surface,
      indicatorColor:   AppColors.dustyBlue.withOpacity(0.18),
      iconTheme: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return const IconThemeData(color: AppColors.dustyBlue, size: 22);
        return const IconThemeData(color: AppColors.textMuted, size: 22);
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) {
          return const TextStyle(color: AppColors.textPrimary, fontSize: 11, fontWeight: FontWeight.w800);
        }
        return const TextStyle(color: AppColors.textMuted, fontSize: 11, fontWeight: FontWeight.w600);
      }),
      elevation:     0,
      overlayColor:  WidgetStateProperty.all(AppColors.dustyBlue.withOpacity(0.08)),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    ),

    drawerTheme: DrawerThemeData(
      backgroundColor:  AppColors.surface,
      elevation:        0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.only(
          topRight:    Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
        side: const BorderSide(color: AppColors.borderActive, width: 2.2),
      ),
    ),

    dialogTheme: DialogThemeData(
      backgroundColor: AppColors.card,
      elevation:       0,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: const BorderSide(color: AppColors.borderActive, width: 2.2),
      ),
      titleTextStyle: const TextStyle(
        fontSize:      18,
        fontWeight:    FontWeight.w900,
        color:         AppColors.textPrimary,
        letterSpacing: 0.4,
      ),
      contentTextStyle: const TextStyle(
        fontSize:   14,
        color:      AppColors.textSub,
        height:     1.5,
        fontWeight: FontWeight.w600,
      ),
    ),

    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor:     AppColors.surface,
      modalBackgroundColor: AppColors.surface,
      elevation:           0,
      modalElevation:      0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        side: BorderSide(color: AppColors.borderActive, width: 2.2),
      ),
      showDragHandle:  true,
      dragHandleColor: AppColors.border,
      dragHandleSize:  Size(40, 4),
      clipBehavior:    Clip.antiAlias,
    ),

    snackBarTheme: SnackBarThemeData(
      backgroundColor:  AppColors.card,
      contentTextStyle: const TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w700),
      actionTextColor:  AppColors.cyan,
      behavior:         SnackBarBehavior.floating,
      elevation:        0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: AppColors.borderGlow, width: 1),
      ),
    ),

    tabBarTheme: TabBarThemeData(
      labelColor:           AppColors.cyan,
      unselectedLabelColor: AppColors.textMuted,
      indicatorColor:       AppColors.cyan,
      indicatorSize:        TabBarIndicatorSize.label,
      labelStyle:           const TextStyle(fontFamily: _fontDisplay, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.8),
      unselectedLabelStyle: const TextStyle(fontFamily: _fontMono,    fontSize: 12),
      overlayColor:         WidgetStateProperty.all(AppColors.cyan.withOpacity(0.06)),
      dividerColor:         AppColors.border,
    ),

    listTileTheme: const ListTileThemeData(
      tileColor:         Colors.transparent,
      selectedTileColor: Color(0x1500E5FF),
      iconColor:         AppColors.textSub,
      selectedColor:     AppColors.cyan,
      textColor:         AppColors.textPrimary,
      subtitleTextStyle: TextStyle(color: AppColors.textSub, fontSize: 12),
      contentPadding:    EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
    ),

    dividerTheme: const DividerThemeData(
      color:     AppColors.border,
      thickness: 1,
      space:     1,
    ),

    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyan;
        return AppColors.textMuted;
      }),
      trackColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyanDark.withOpacity(0.6);
        return AppColors.border;
      }),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      overlayColor:      WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
    ),

    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyan;
        return Colors.transparent;
      }),
      checkColor:   WidgetStateProperty.all(AppColors.bg),
      side:         const BorderSide(color: AppColors.borderGlow, width: 1.5),
      shape:        RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      overlayColor: WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
    ),

    radioTheme: RadioThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return AppColors.cyan;
        return AppColors.textMuted;
      }),
      overlayColor: WidgetStateProperty.all(AppColors.cyan.withOpacity(0.08)),
    ),

    sliderTheme: SliderThemeData(
      activeTrackColor:    AppColors.cyan,
      inactiveTrackColor:  AppColors.border,
      thumbColor:          AppColors.cyan,
      overlayColor:        AppColors.cyan.withOpacity(0.12),
      valueIndicatorColor: AppColors.cyanDark,
      valueIndicatorTextStyle: const TextStyle(color: AppColors.bg, fontSize: 12, fontFamily: _fontMono),
      trackHeight:         3,
      thumbShape:          const RoundSliderThumbShape(enabledThumbRadius: 7),
    ),

    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color:              AppColors.cyan,
      linearTrackColor:   AppColors.border,
      circularTrackColor: AppColors.border,
      linearMinHeight:    3,
    ),

    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor:    AppColors.cyan,
      foregroundColor:    AppColors.bg,
      elevation:          0,
      focusElevation:     0,
      hoverElevation:     0,
      highlightElevation: 0,
      splashColor:        AppColors.textPrimary.withOpacity(0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),

    iconTheme:        const IconThemeData(color: AppColors.cyanDim, size: 22),
    primaryIconTheme: const IconThemeData(color: AppColors.cyan,    size: 22),

    popupMenuTheme: PopupMenuThemeData(
      color:            AppColors.card,
      elevation:        0,
      shadowColor:      Colors.transparent,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: AppColors.borderGlow, width: 1),
      ),
      textStyle: const TextStyle(color: AppColors.textPrimary, fontFamily: _fontMono, fontSize: 13),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(color: AppColors.textPrimary, fontFamily: _fontMono, fontSize: 13),
      ),
      iconColor: AppColors.textSub,
    ),

    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color:        AppColors.surface,
        borderRadius: BorderRadius.circular(8),
        border:       Border.all(color: AppColors.borderGlow),
      ),
      textStyle: const TextStyle(color: AppColors.textPrimary, fontSize: 11, fontFamily: _fontMono),
      padding:   const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    ),

    scrollbarTheme: ScrollbarThemeData(
      thumbColor:      WidgetStateProperty.all(AppColors.borderGlow),
      trackColor:      WidgetStateProperty.all(AppColors.surface),
      radius:          const Radius.circular(4),
      thickness:       WidgetStateProperty.all(3),
      crossAxisMargin: 2,
    ),

    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: _NebulaTransitionBuilder(),
        TargetPlatform.iOS:     _NebulaTransitionBuilder(),
        TargetPlatform.windows: _NebulaTransitionBuilder(),
        TargetPlatform.macOS:   _NebulaTransitionBuilder(),
        TargetPlatform.linux:   _NebulaTransitionBuilder(),
      },
    ),

    textTheme: const TextTheme(
      displayLarge:   TextStyle(fontSize: 40, fontWeight: FontWeight.w800, color: AppColors.textPrimary, height: 1.08),
      displayMedium:  TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.textPrimary, height: 1.12),
      displaySmall:   TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
      headlineLarge:  TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
      headlineMedium: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      headlineSmall:  TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      titleLarge:     TextStyle(fontSize: 19, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      titleMedium:    TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      titleSmall:     TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
      bodyLarge:      TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: AppColors.textPrimary, height: 1.5),
      bodyMedium:     TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppColors.textPrimary, height: 1.45),
      bodySmall:      TextStyle(fontSize: 12, fontWeight: FontWeight.w500, color: AppColors.textSub, height: 1.4),
      labelLarge:     TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
      labelMedium:    TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSub),
      labelSmall:     TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textMuted),
    ),
  );
}

// ═══════════════════════════════════════════════════════════════
//  NEBULA PAGE TRANSITION — Fade + Scale
// ═══════════════════════════════════════════════════════════════
class _NebulaTransitionBuilder extends PageTransitionsBuilder {
  const _NebulaTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(parent: animation,          curve: Curves.easeOutExpo);
    final outCurve = CurvedAnimation(parent: secondaryAnimation,  curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, 0.025), end: Offset.zero).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.80).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.96).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  PREMIUM SHARED WIDGETS
// ═══════════════════════════════════════════════════════════════

/// Tombol Utama Premium — Neon Cyan Gradient dengan glow effect
class NeonButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool isLoading;
  final double? width;
  final Color? color;

  const NeonButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.isLoading = false,
    this.width,
    this.color,
  });

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _scale = Tween<double>(begin: 1.0, end: 0.96).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeOut),
    );
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final baseColor = widget.color ?? AppColors.cyan;
    return GestureDetector(
      onTapDown: (_) { setState(() => _pressed = true); _ctrl.forward(); },
      onTapUp: (_)   { setState(() => _pressed = false); _ctrl.reverse(); widget.onTap?.call(); },
      onTapCancel: () { setState(() => _pressed = false); _ctrl.reverse(); },
      child: ScaleTransition(
        scale: _scale,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width:  widget.width,
          height: 50,
          decoration: BoxDecoration(
            color: _pressed ? baseColor.withOpacity(.82) : baseColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.primaryDark, width: 1.2),
            boxShadow: const [],
          ),
          child: widget.isLoading
              ? Center(child: SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(AppColors.bg),
                  ),
                ))
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (widget.icon != null) ...[
                      Icon(widget.icon, size: 16, color: AppColors.bg),
                      const SizedBox(width: 8),
                    ],
                    Text(
                      widget.label,
                      style: const TextStyle(
                        fontFamily:    'Orbitron',
                        fontSize:      12,
                        fontWeight:    FontWeight.w700,
                        color:         AppColors.bg,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

/// Tombol Outline Premium — Ghost button
class GhostButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final Color? color;
  final double? width;

  const GhostButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.color,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.cyan;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width:  width,
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: c.withOpacity(0.5), width: 1.5),
          color: c.withOpacity(0.05),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 16, color: c),
              const SizedBox(width: 8),
            ],
            Text(
              label,
              style: TextStyle(
                fontFamily:    'Orbitron',
                fontSize:      11,
                fontWeight:    FontWeight.w600,
                color:         c,
                letterSpacing: 1.0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Comic 3D surface — hard depth, clean outline, readable content.
class Comic3DCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color color;
  final Color depthColor;
  final double radius;
  final VoidCallback? onTap;
  final bool compact;

  const Comic3DCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color = AppColors.card,
    this.depthColor = AppColors.borderActive,
    this.radius = 18,
    this.onTap,
    this.compact = false,
  });

  @override
  State<Comic3DCard> createState() => _Comic3DCardState();
}

class _Comic3DCardState extends State<Comic3DCard> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final depth = widget.compact ? 4.0 : 7.0;
    return GestureDetector(
      onTapDown: widget.onTap == null ? null : (_) => setState(() => _pressed = true),
      onTapCancel: widget.onTap == null ? null : () => setState(() => _pressed = false),
      onTapUp: widget.onTap == null ? null : (_) => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 110),
        transform: Matrix4.translationValues(0, _pressed ? depth : 0, 0),
        curve: Curves.easeOut,
        padding: EdgeInsets.only(bottom: _pressed ? 0 : depth),
        decoration: BoxDecoration(
          color: _pressed ? Colors.transparent : widget.depthColor.withOpacity(.72),
          borderRadius: BorderRadius.circular(widget.radius),
        ),
        child: Container(
          padding: widget.padding,
          decoration: BoxDecoration(
            color: widget.color,
            borderRadius: BorderRadius.circular(widget.radius),
            border: Border.all(color: AppColors.textPrimary.withOpacity(.18), width: 1.35),
            boxShadow: const [],
          ),
          child: widget.child,
        ),
      ),
    );
  }
}

/// Backward compatible name used by existing pages.
class PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Color? glowColor;
  final bool showGlow;
  final double radius;
  const PremiumCard({super.key, required this.child, this.padding, this.glowColor, this.showGlow = false, this.radius = 18});
  @override
  Widget build(BuildContext context) => Comic3DCard(
    padding: padding ?? const EdgeInsets.all(16),
    depthColor: showGlow ? (glowColor ?? AppColors.cyanDark) : AppColors.borderActive,
    radius: radius,
    child: child,
  );
}

class Comic3DButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color color;
  const Comic3DButton({super.key, required this.label, this.icon, this.onPressed, this.color = AppColors.cyan});
  @override State<Comic3DButton> createState() => _Comic3DButtonState();
}
class _Comic3DButtonState extends State<Comic3DButton> {
  bool down = false;
  @override Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onPressed == null ? null : (_) => setState(() => down = true),
      onTapCancel: () => setState(() => down = false),
      onTapUp: (_) => setState(() => down = false),
      onTap: widget.onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        transform: Matrix4.translationValues(0, down ? 4 : 0, 0),
        padding: EdgeInsets.only(bottom: down ? 0 : 5),
        decoration: BoxDecoration(color: widget.color.withOpacity(.72), borderRadius: BorderRadius.circular(15)),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
          decoration: BoxDecoration(color: widget.color, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.textPrimary.withOpacity(.22), width: 1.2)),
          child: Row(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
            if (widget.icon != null) ...[Icon(widget.icon, color: Colors.white, size: 19), const SizedBox(width: 8)],
            Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
          ]),
        ),
      ),
    );
  }
}

class ComicSectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData? icon;
  const ComicSectionHeader({super.key, required this.title, this.subtitle, this.icon});
  @override Widget build(BuildContext context) => Row(children: [
    if (icon != null) Container(width: 38, height: 38, margin: const EdgeInsets.only(right: 10), decoration: BoxDecoration(color: AppColors.cyan.withOpacity(.12), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.cyan.withOpacity(.3))), child: Icon(icon, color: AppColors.cyan)),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.textPrimary)), if (subtitle != null) ...[const SizedBox(height: 2), Text(subtitle!, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textSub))]])),
  ]);
}

/// Comic 3D background — subtle shapes, never behind text
class NebulaBackground extends StatelessWidget {
  final Widget child;
  const NebulaBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => ColoredBox(color: AppColors.bg, child: child);
}


class _DotGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Background polos — tanpa hiasan
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFF0E6D2));
  }

  @override
  bool shouldRepaint(_) => false;
}

// ═══════════════════════════════════════════════════════════════
//  ROUTE BUILDER
// ═══════════════════════════════════════════════════════════════
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  late final Widget page;
  final route = settings.name;
  if (route == '/') {
    page = LandingPage();
  } else if (route == '/login') {
    page = const LoginPage();
  } else if (route == '/dashboard') {
    final a = args!;
    page = DashboardPage(
      username: a['username'] as String,
      password: a['password'] as String,
      role: a['role'] as String,
      sessionKey: a['key'] as String,
      expiredDate: a['expiredDate'] as String,
      listBug: List<Map<String, dynamic>>.from(a['listBug'] ?? []),
      listDoos: List<Map<String, dynamic>>.from(a['listDoos'] ?? []),
      news: List<Map<String, dynamic>>.from(a['news'] ?? []),
    );
  } else if (route == '/home') {
    final a = args!;
    page = HomePage(
      username: a['username'] as String,
      password: a['password'] as String,
      role: a['role'] as String,
      expiredDate: a['expiredDate'] as String,
      sessionKey: a['sessionKey'] as String,
      listBug: List<Map<String, dynamic>>.from(a['listBug'] ?? []),
    );
  } else if (route == '/seller') {
    page = SellerPage(keyToken: args!['keyToken'] as String);
  } else if (route == '/admin') {
    page = AdminPage(sessionKey: args!['sessionKey'] as String);
  } else if (route == '/owner') {
    final a = args!;
    page = OwnerPage(sessionKey: a['sessionKey'] as String, username: a['username'] as String);
  } else {
    page = _NotFoundPage(routeName: route ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration:        const Duration(milliseconds: 340),
    reverseTransitionDuration: const Duration(milliseconds: 280),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(parent: animation,         curve: Curves.easeOutExpo);
      final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);
      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.025), end: Offset.zero).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.80).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.96).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ═══════════════════════════════════════════════════════════════
//  404 PAGE — PREMIUM NEBULA STYLE
// ═══════════════════════════════════════════════════════════════
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: NebulaBackground(
        child: Center(
          child: FadeTransition(
            opacity: _fade,
            child: SlideTransition(
              position: _slide,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedBuilder(
                      animation: _glow,
                      builder: (_, child) => Container(
                        width: 96, height: 96,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color:  AppColors.surface,
                          border: Border.all(color: AppColors.borderGlow, width: 1.5),
                          boxShadow: [
                            BoxShadow(
                              color:       AppColors.cyan.withOpacity(0.20 * _glow.value),
                              blurRadius: 0,
                              spreadRadius: 8,
                            ),
                          ],
                        ),
                        child: child,
                      ),
                      child: const Icon(Icons.explore_off_rounded, color: AppColors.textSub, size: 36),
                    ),
                    const SizedBox(height: 32),
                    ShaderMask(
                      shaderCallback: (b) => const LinearGradient(
                        colors: [AppColors.cyan, AppColors.violetBright],
                      ).createShader(b),
                      child: const Text(
                        '404',
                        style: TextStyle(
                          fontFamily:    'Orbitron',
                          fontSize:      80,
                          fontWeight:    FontWeight.w900,
                          color:         Colors.white,
                          letterSpacing: 4,
                          height:        1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'PAGE NOT FOUND',
                      style: TextStyle(
                        fontFamily:    'Orbitron',
                        fontSize:      13,
                        fontWeight:    FontWeight.w600,
                        color:         AppColors.textSub,
                        letterSpacing: 3,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color:        AppColors.surface,
                        borderRadius: BorderRadius.circular(8),
                        border:       Border.all(color: AppColors.border),
                      ),
                      child: Text(
                        '"${widget.routeName}"',
                        style: const TextStyle(
                          fontFamily: 'ShareTechMono',
                          fontSize:   12,
                          color:      AppColors.textMuted,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                    NeonButton(
                      label: 'BACK TO HOME',
                      icon:  Icons.arrow_back_rounded,
                      onTap: () => Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false),
                      width: 200,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
//  ENTRY POINT
// ═══════════════════════════════════════════════════════════════
void main() {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.bg,
    systemNavigationBarIconBrightness: Brightness.dark,
    systemNavigationBarDividerColor: Colors.transparent,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _LightStarApp());
}

// ═══════════════════════════════════════════════════════════════
//  ROOT APP
// ═══════════════════════════════════════════════════════════════
class _LightStarApp extends StatelessWidget {
  const _LightStarApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title:           'Xeon',
      theme:           AppTheme.build(),
      initialRoute:    '/',
      onGenerateRoute: _generateRoute,
      navigatorObservers: [dashboardRouteObserver],
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(
              mq.textScaler.scale(1.0).clamp(0.85, 1.2),
            ),
          ),
          child: ComicAppShell(child: child ?? const SizedBox.shrink()),
        );
      },
    );
  }
}
