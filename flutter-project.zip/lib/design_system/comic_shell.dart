import 'package:flutter/gestures.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart';


class ComicBackgroundController {
  static final ValueNotifier<String?> path = ValueNotifier<String?>(null);
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('xeon_custom_background');
    if (saved != null && await File(saved).exists()) {
      path.value = saved;
    } else if (saved != null) {
      await prefs.remove('xeon_custom_background');
    }
  }

  static Future<void> pick() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 88);
    if (picked == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final target = File('${dir.path}/xeon_custom_background.jpg');
    await File(picked.path).copy(target.path);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('xeon_custom_background', target.path);
    path.value = target.path;
  }

  static Future<void> reset() async {
    final old = path.value;
    path.value = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('xeon_custom_background');
    if (old != null) {
      final file = File(old);
      if (await file.exists()) await file.delete();
    }
  }
}

Future<void> showComicBackgroundPicker(BuildContext context) async {
  await ComicBackgroundController.load();
  if (!context.mounted) return;
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (sheetContext) => SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border.all(color: AppColors.borderActive, width: 2),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 42, height: 5, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(9))),
          const SizedBox(height: 14),
          const Align(alignment: Alignment.centerLeft, child: Text('CUSTOM BACKGROUND', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900))),
          const SizedBox(height: 6),
          const Align(alignment: Alignment.centerLeft, child: Text('Pilih background pribadi tanpa mengubah Banner Tools.', style: TextStyle(color: AppColors.textSub, fontSize: 12))),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: ElevatedButton.icon(onPressed: () async { Navigator.pop(sheetContext); await ComicBackgroundController.pick(); }, icon: const Icon(Icons.photo_library_rounded), label: const Text('PILIH GAMBAR'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: () async { Navigator.pop(sheetContext); await ComicBackgroundController.reset(); }, icon: const Icon(Icons.restore_rounded), label: const Text('RESET'))),
          ]),
        ]),
      ),
    ),
  );
}

/// Global 3D Comic shell — visual only.
/// Semua route melewati layer ini. Tidak mengubah logic/nav/API.
class ComicAppShell extends StatelessWidget {
  final Widget child;
  const ComicAppShell({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    ComicBackgroundController.load();
    final base = Theme.of(context);
    final comicTheme = base.copyWith(
      splashFactory: NoSplash.splashFactory,
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      hoverColor: Colors.transparent,
      pageTransitionsTheme: PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      }),
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.textPrimary,
        displayColor: AppColors.textPrimary,
      ),
    );

    return ColoredBox(
      color: AppColors.bg,
      child: ScrollConfiguration(
        behavior: const _ComicScrollBehavior(),
        child: Theme(
          data: comicTheme,
          child: IconTheme.merge(
            data: const IconThemeData(color: AppColors.dustyBlue),
            child: Stack(
              fit: StackFit.expand,
              children: [
                const IgnorePointer(child: _ComicWorldBackdrop()),
                ValueListenableBuilder<String?>(
                  valueListenable: ComicBackgroundController.path,
                  builder: (context, path, _) => path == null
                      ? const SizedBox.shrink()
                      : IgnorePointer(
                          child: Opacity(
                            opacity: .20,
                            child: Image.file(File(path), fit: BoxFit.cover),
                          ),
                        ),
                ),
                DefaultTextStyle.merge(
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w600,
                    height: 1.3,
                    decoration: TextDecoration.none,
                  ),
                  child: child,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Soft premium backdrop — subtle wash + very light texture.
/// Tidak berlebihan, tetap clean & modern.
class _ComicWorldBackdrop extends StatelessWidget {
  const _ComicWorldBackdrop();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _ComicWorldPainter(),
      child: const SizedBox.expand(),
    );
  }
}

class _ComicWorldPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Background polos — cream solid, tanpa hiasan
    final bg = Paint()..color = AppColors.bg;
    canvas.drawRect(Offset.zero & size, bg);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ComicScrollBehavior extends MaterialScrollBehavior {
  const _ComicScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
        PointerDeviceKind.trackpad,
      };

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());
  }

  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child;
  }
}
