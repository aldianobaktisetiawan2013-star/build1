import 'package:flutter/material.dart';
import '../main.dart';

// ═══════════════════════════════════════════════════════════════
//  PROFESSIONAL 3D COMIC DESIGN SYSTEM
//  Soft depth • Muted pastel accents • Clean hierarchy
// ═══════════════════════════════════════════════════════════════

class AppSpacing {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double xxl = 32;
  static const double xxxl = 40;
}

class AppRadius {
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 20;
  static const double xl = 24;
  static const double pill = 999;
}

class AppShadows {
  /// Soft elevated card shadow (premium, not harsh)
  static List<BoxShadow> card = [
    BoxShadow(
      color: const Color(0xFF1A1816).withOpacity(0.07),
      offset: const Offset(0, 4),
      blurRadius: 12,
      spreadRadius: 0,
    ),
    BoxShadow(
      color: const Color(0xFF1A1816).withOpacity(0.04),
      offset: const Offset(0, 1),
      blurRadius: 3,
    ),
  ];

  /// Subtle press / depth shadow
  static List<BoxShadow> pressed = [
    BoxShadow(
      color: const Color(0xFF1A1816).withOpacity(0.06),
      offset: const Offset(0, 2),
      blurRadius: 6,
    ),
  ];

  /// Soft button extrusion
  static List<BoxShadow> button = [
    BoxShadow(
      color: const Color(0xFF1A1816).withOpacity(0.12),
      offset: const Offset(0, 3),
      blurRadius: 0,
    ),
  ];
}

// ─────────────────────────────────────────────────────────────
//  Background wrapper
// ─────────────────────────────────────────────────────────────
class ComicBackground extends StatelessWidget {
  final Widget child;
  const ComicBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Colors.transparent,
      child: SafeArea(top: false, bottom: false, child: child),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Comic3DCard — soft extrusion + elegant outline
// ─────────────────────────────────────────────────────────────
class Comic3DCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color color;
  final Color? accentColor;
  final double radius;
  final double borderWidth;
  final bool elevated;

  const Comic3DCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.onTap,
    this.color = AppColors.card,
    this.accentColor,
    this.radius = 20,
    this.borderWidth = 2.2,
    this.elevated = true,
  });

  @override
  State<Comic3DCard> createState() => _Comic3DCardState();
}

class _Comic3DCardState extends State<Comic3DCard> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final depthColor = widget.accentColor ?? AppColors.borderActive;
    const depth = 3.0;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.onTap == null ? null : (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.975 : 1.0,
        duration: const Duration(milliseconds: 90),
        curve: Curves.easeOutCubic,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          curve: Curves.easeOutCubic,
          margin: EdgeInsets.only(
            top: _down ? depth : 0,
            bottom: _down ? 0 : depth,
          ),
          decoration: BoxDecoration(
            color: depthColor.withOpacity(0.85),
            borderRadius: BorderRadius.circular(widget.radius),
            boxShadow: _down || !widget.elevated ? AppShadows.pressed : AppShadows.card,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: widget.color,
              borderRadius: BorderRadius.circular(widget.radius),
              border: Border.all(
                color: AppColors.borderActive.withOpacity(0.92),
                width: widget.borderWidth,
              ),
            ),
            padding: widget.padding,
            child: widget.child,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Accent Menu Card — one muted accent per card
// ─────────────────────────────────────────────────────────────
class ComicMenuCard extends StatefulWidget {
  final IconData icon;
  final String label;
  final String? subtitle;
  final Color accent;
  final VoidCallback? onTap;
  final double? height;

  const ComicMenuCard({
    super.key,
    required this.icon,
    required this.label,
    this.subtitle,
    required this.accent,
    this.onTap,
    this.height,
  });

  @override
  State<ComicMenuCard> createState() => _ComicMenuCardState();
}

class _ComicMenuCardState extends State<ComicMenuCard> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    const depth = 3.5;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 90),
        curve: Curves.easeOutCubic,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 90),
          height: widget.height,
          margin: EdgeInsets.only(top: _down ? depth : 0, bottom: _down ? 0 : depth),
          decoration: BoxDecoration(
            color: widget.accent.withOpacity(0.9),
            borderRadius: BorderRadius.circular(20),
            boxShadow: _down ? AppShadows.pressed : AppShadows.card,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.card,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.borderActive.withOpacity(0.9), width: 2.2),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: widget.accent.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: widget.accent.withOpacity(0.55),
                      width: 1.8,
                    ),
                  ),
                  child: Icon(widget.icon, size: 24, color: widget.accent),
                ),
                const SizedBox(height: 12),
                Text(
                  widget.label,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textPrimary,
                    height: 1.2,
                    letterSpacing: 0.15,
                  ),
                ),
                if (widget.subtitle != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    widget.subtitle!,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textMuted,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Badge
// ─────────────────────────────────────────────────────────────
class ComicBadge extends StatelessWidget {
  final String label;
  final IconData? icon;
  final Color? color;

  const ComicBadge({super.key, required this.label, this.icon, this.color});

  @override
  Widget build(BuildContext context) {
    final bg = color ?? AppColors.softMustard;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: bg.withOpacity(0.22),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: bg.withOpacity(0.7), width: 1.6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: bg),
            const SizedBox(width: 5),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  List Tile
// ─────────────────────────────────────────────────────────────
class ComicListTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? iconBg;
  final bool destructive;

  const ComicListTile({
    super.key,
    required this.icon,
    required this.label,
    this.onTap,
    this.iconBg,
    this.destructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final border = destructive ? AppColors.danger : AppColors.borderActive;
    final bg = destructive ? AppColors.danger.withOpacity(0.06) : AppColors.card;
    final accent = iconBg ?? (destructive ? AppColors.danger : AppColors.dustyBlue);

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: border.withOpacity(0.9), width: 2.0),
              boxShadow: AppShadows.pressed,
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.16),
                    shape: BoxShape.circle,
                    border: Border.all(color: accent.withOpacity(0.5), width: 1.6),
                  ),
                  child: Icon(
                    icon,
                    size: 18,
                    color: destructive ? AppColors.danger : accent,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: destructive ? AppColors.danger : AppColors.textPrimary,
                      letterSpacing: 0.15,
                    ),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  color: destructive ? AppColors.danger : AppColors.textMuted,
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  CTA Button — dimensional
// ─────────────────────────────────────────────────────────────
class ComicCtaButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final Color color;
  final IconData? icon;
  final bool loading;

  const ComicCtaButton({
    super.key,
    required this.label,
    this.onPressed,
    this.color = AppColors.dustyBlue,
    this.icon,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return Comic3DCard(
      color: color,
      accentColor: color.withOpacity(0.75),
      padding: EdgeInsets.zero,
      radius: 16,
      borderWidth: 2.2,
      onTap: loading ? null : onPressed,
      child: SizedBox(
        height: 52,
        child: loading
            ? const Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.4,
                    color: Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                  ],
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 14,
                      letterSpacing: 0.6,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Section Title
// ─────────────────────────────────────────────────────────────
class ComicSectionTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? action;

  const ComicSectionTitle({
    super.key,
    required this.title,
    this.subtitle,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                  color: AppColors.textPrimary,
                  letterSpacing: -0.2,
                  height: 1.15,
                ),
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 3),
                Text(
                  subtitle!,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSub,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          ),
        ),
        if (action != null) action!,
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Header bar component
// ─────────────────────────────────────────────────────────────
class XeonComicHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final Widget? trailing;
  final Color? accent;

  const XeonComicHeader({
    super.key,
    required this.title,
    this.subtitle,
    this.icon = Icons.auto_awesome_rounded,
    this.trailing,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final a = accent ?? AppColors.dustyBlue;
    return Comic3DCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      accentColor: a,
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: a.withOpacity(0.16),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: a.withOpacity(0.55), width: 1.8),
            ),
            child: Icon(icon, color: a, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    letterSpacing: 0.15,
                    color: AppColors.textPrimary,
                  ),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSub,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ],
            ),
          ),
          if (trailing != null) ...[const SizedBox(width: 10), trailing!],
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  Empty / Loading / Error states
// ─────────────────────────────────────────────────────────────
class ComicEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;

  const ComicEmptyState({
    super.key,
    this.icon = Icons.inbox_rounded,
    required this.title,
    this.message,
    this.action,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: AppColors.dustyBlue.withOpacity(0.12),
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppColors.dustyBlue.withOpacity(0.35),
                  width: 2,
                ),
              ),
              child: Icon(icon, size: 32, color: AppColors.dustyBlue),
            ),
            const SizedBox(height: 18),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w800,
                color: AppColors.textPrimary,
              ),
            ),
            if (message != null) ...[
              const SizedBox(height: 8),
              Text(
                message!,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  color: AppColors.textSub,
                  height: 1.4,
                ),
              ),
            ],
            if (action != null) ...[
              const SizedBox(height: 20),
              action!,
            ],
          ],
        ),
      ),
    );
  }
}

class ComicLoading extends StatelessWidget {
  final String? message;
  const ComicLoading({super.key, this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 36,
            height: 36,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              color: AppColors.dustyBlue,
              backgroundColor: AppColors.dustyBlue.withOpacity(0.15),
            ),
          ),
          if (message != null) ...[
            const SizedBox(height: 14),
            Text(
              message!,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.textSub,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
